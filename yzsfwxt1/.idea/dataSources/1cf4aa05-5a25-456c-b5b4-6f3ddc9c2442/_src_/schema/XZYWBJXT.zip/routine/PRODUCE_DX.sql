CREATE procedure Produce_Dx is
/* --------------------------------------
生成短信 3种类型  1 业务黄灯提醒 2 业务即将红灯 3 业务红灯通知
【业务黄灯提醒】[项目名称][环节名称]（任务编号：[任务编号]），已于[绿灯办结时限]亮黄灯，敬请关注。
----------------------------------------*/
v_exception  varchar2(1000);
i_count int;
tempresult varchar2(36);
i_dxmb varchar2(500);

begin

  -----1.业务黄灯提醒
  ---查询模板
  select dxmb into i_dxmb from dx_mbpz t where t.id='1';
  insert into dx_dfs
    (id, dxmbid, fsr, fssj, fscs, fsnr, jsr, jshm, taskid)
  select sys_guid(),1,'system',sysdate,0,replace(replace(replace(replace(i_dxmb,'[项目名称]',t.xmmc),'[环节名称]',acti.activityname),'[任务编号]',t.rwbh),'[绿灯办结时限]',t.jssx),
  t.czr,f_get_sjhm(t.czr),t.taskid
   from get_wdrw_dblb t 
   join wf_df_activity acti on t.c_activityid=acti.activityid
   where not exists(select 1 from dx_user_pz a where a.userid=t.czr and a.dxmbid=1)
   and not exists(select 1 from get_all_dx b where b.dxmbid=1 and t.taskid=b.taskid) and sfhuangd=1;
   commit;
   
     -----2.业务即将红灯
  ---查询模板
  select dxmb into i_dxmb from dx_mbpz t where t.id='2';
  insert into dx_dfs
    (id, dxmbid, fsr, fssj, fscs, fsnr, jsr, jshm, taskid)
  select sys_guid(),2,'system',sysdate,0,replace(replace(replace(replace(i_dxmb,'[项目名称]',t.xmmc),'[环节名称]',acti.activityname),'[任务编号]',t.rwbh),'[黄灯办结时限]',t.jssx_yl-1),
  t.czr,f_get_sjhm(t.czr),t.taskid
   from get_wdrw_dblb t 
   join wf_df_activity acti on t.c_activityid=acti.activityid
   where not exists(select 1 from dx_user_pz a where a.userid=t.czr and a.dxmbid=2)
   and not exists(select 1 from get_all_dx b where b.dxmbid=2 and t.taskid=b.taskid) and t.jssx_yl-1<sysdate;
   commit;
   
  -----3.业务红灯提醒
  ---查询模板
  select dxmb into i_dxmb from dx_mbpz t where t.id='3';
  insert into dx_dfs
    (id, dxmbid, fsr, fssj, fscs, fsnr, jsr, jshm, taskid)
  select sys_guid(),3,'system',sysdate,0,replace(replace(replace(replace(i_dxmb,'[项目名称]',t.xmmc),'[环节名称]',acti.activityname),'[任务编号]',t.rwbh),'[黄灯办结时限]',t.jssx_yl),
  t.czr,f_get_sjhm(t.czr),t.taskid
   from get_wdrw_dblb t 
   join wf_df_activity acti on t.c_activityid=acti.activityid
   where not exists(select 1 from dx_user_pz a where a.userid=t.czr and a.dxmbid=3)
   and not exists(select 1 from get_all_dx b where b.dxmbid=3 and t.taskid=b.taskid) and sfhongd=1;
   commit;

  exception
      when others then
        begin
          --记录日志
           v_exception:=sqlerrm;
           insert into Calc_Pro_LOG(type,sj,message) values('生成短信',sysdate,v_exception);
           commit;
        end;
end Produce_Dx;
/

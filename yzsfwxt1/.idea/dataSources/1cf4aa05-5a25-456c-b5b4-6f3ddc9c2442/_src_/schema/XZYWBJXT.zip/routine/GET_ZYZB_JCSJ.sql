CREATE procedure get_zyzb_jcsj(v_begintime date,
                                                   v_endtime date,
                                                   icyclekind integer) as
    ---------计算周期 1 月 2 季 3 年
    p_begindate date;
    p_first date;
    p_enddate date;
    p_last date;
    v_exception  varchar2(1000);
    iweekly number;
begin
    p_begindate := v_begintime;
    p_enddate   := v_endtime;

    if(icyclekind=1) then
        while p_begindate < p_enddate loop
          p_first := TRUNC(p_begindate,'mm');--本月1号
          p_last := TRUNC(add_months(p_begindate,1),'mm')-1;--本月最后一天
          iweekly:= to_char(p_begindate,'mm');---为多少月
          --get_ykbz_collect_calc(p_first,p_last,icyclekind,iweekly);
          p_begindate:=add_months(p_begindate,1);
       end loop;
    elsif(icyclekind=2) then --季度
     while p_begindate < p_enddate loop
          p_first := TRUNC(p_begindate,'Q');--本季度1号
          p_last := TRUNC(add_months(p_begindate,3),'Q')-1;--本季度最后一天
          iweekly:= to_char(p_begindate,'Q');---为多少季度
          --get_ykbz_collect_calc(p_first,p_last,icyclekind,iweekly);
          p_begindate:=add_months(p_begindate,3);
       end loop;
    else
     while p_begindate < p_enddate loop
          p_first := TRUNC(p_begindate,'YYYY');--本年1号
          p_last := TRUNC(add_months(p_begindate,12),'YYYY')-1;--本年最后一天
          iweekly:= to_char(p_begindate,'yyyy');---为多少年
          /*get_ykbz_collect_calc(p_first,p_last,icyclekind,iweekly);
          calc_ykbz_avg_except(p_first,p_last,icyclekind,iweekly);*/
          p_begindate:=add_months(p_begindate,12);
       end loop;
    end if;



     exception
      when others then
        begin
          --记录日志
           v_exception:=sqlerrm;
           insert into calc_pro_log(type,sj,message) values('流程办理汇总统计',sysdate,v_exception);
           commit;
         rollback;
        end;
end;
/

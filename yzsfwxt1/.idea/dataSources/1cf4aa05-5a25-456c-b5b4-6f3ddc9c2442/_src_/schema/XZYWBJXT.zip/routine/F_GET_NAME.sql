CREATE function f_get_name(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select codename into Result from xtgl_code t where t.CODEVALUE=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

CREATE procedure GET_MrZpr(v_XMID IN VARCHAR2,v_Type IN VARCHAR2,i_result out VARCHAR2) is
/* --------------------------------------
获取默认选择指派人员
v_Type 1 设计人员 2 区所 select sys_guid() from dual;
----------------------------------------*/
v_exception  varchar2(1000);
i_count int;
tempresult varchar2(36);
i_pxmid varchar2(36);

begin
  if(v_Type='1') then
    -----获取此项目设计人员
    select nvl(SJFZR,'') into tempresult from xm_instance a where a.ID=v_XMID;
    if(tempresult is not NULL) then
          i_result:=tempresult;
    else
      -----判断是否第一个项目
      select nvl(pxmid,'') into i_pxmid from xm_instance a where a.ID=v_XMID;
      if(i_pxmid is not NULL) then
          ---获取其他项目的设计人员
          select count(1) into i_count from  xm_instance t where t.pxmid=i_pxmid and t.ID<>v_XMID;
          if (i_count>0) then
          select nvl(SJFZR,'') into tempresult from
          (select t.SJFZR,
               row_number() over(partition by t.pxmid order by t.slsj desc) rn
          from xm_instance t where t.pxmid=i_pxmid and t.ID<>v_XMID) where rn=1;
          i_result:=tempresult;
          else
             i_result:='';
          end if;
      else
          i_result:='';
      end if;
     end if;
   elsif(v_Type='2') then
        -----获取此项目区所人员
    select nvl(QSFZR,'') into tempresult from xm_instance a where a.ID=v_XMID;
    if(tempresult is not NULL) then
          i_result:=tempresult;
    else
      -----判断是否第一个项目
      select nvl(pxmid,'') into i_pxmid from xm_instance a where a.ID=v_XMID;
      if(i_pxmid is not NULL) then
          ---获取其他项目的区所人员
           select count(1) into i_count from  xm_instance t where t.pxmid=i_pxmid and t.ID<>v_XMID;
          if (i_count>0) then
          select nvl(QSFZR,'') into tempresult from
          (select t.QSFZR,
               row_number() over(partition by t.pxmid order by t.slsj desc) rn
          from xm_instance t where t.pxmid=i_pxmid and t.ID<>v_XMID) where rn=1;
          i_result:=tempresult;
          else
             i_result:='';
          end if;
      else
          i_result:='';
      end if;
     end if;
   end if;
  exception
      when others then
        begin
          --记录日志
           v_exception:=sqlerrm;
           insert into Calc_Pro_LOG(type,sj,message) values('获取默认选择分派人',sysdate,v_exception);
           commit;
           i_result:='';
        end;
end GET_MrZpr;
/

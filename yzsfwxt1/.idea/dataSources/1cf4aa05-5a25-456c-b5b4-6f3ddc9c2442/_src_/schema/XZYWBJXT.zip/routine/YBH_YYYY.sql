CREATE procedure ybh_yyyy(v_XMID IN VARCHAR2,v_Type IN VARCHAR2,i_result out VARCHAR2) is
begin
select *
 from yzsfw.bl_hbsqb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20' and b.status='正在进行';



select * from wf_instance b where b.wfid='20' and b.isxm=1 and b.operation>date'2017-1-1';



select distinct b.wfinid--a.sjzlzbbh
 from yzsfw.bl_sjzlzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20' and b.status='正在进行';


select distinct a.htysdbh--a.sjzlzbbh
 from yzsfw.bl_htyszb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20' and b.status='正在进行';


select a.tzdzt,count(distinct a.tzdid)--a.sjzlzbbh
 from yzsfw.bl_sftzdzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20'  group by a.tzdzt;



select *
 from yzsfw.bl_dzjzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20';


select *
 from yzsfw.bl_dbsqb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' and b.status='已经完成';



select *--a.sjzlzbbh
 from yzsfw.bl_gwdcdzb a
 join yzsfw.bl_gwdcdcb aa on a.dcdbh=aa.dcdbh
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' ;

select distinct b.wfinid--a.sjzlzbbh
 from yzsfw.bl_sjzlzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' and b.status='正在进行';

select *--a.sjzlzbbh
 from yzsfw.BL_XCKCZB a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='20' ;



select hhlxbh,count(a.id)--a.sjzlzbbh
 from yzsfw.bl_sbbjb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' group by a.hhlxbh ;


select *--distinct b.wfinid--a.sjzlzbbh
 from yzsfw.bl_sjzlzb a
 join bl_sjzlcb aa on a.sjzlzbbh=aa.sjzlzbbh
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' and b.status='正在进行';


select distinct b.wfinid from bl_sjstsqb t
join bl_sjstcb a on t.id=a.sjstzbbh
join yzsfw.wf_instance b on t.wfinid=b.wfinid
where b.wfid='20' and b.status='正在进行';


select distinct a.htysdbh--a.sjzlzbbh
 from yzsfw.bl_htyszb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' and b.status='正在进行';



select distinct a.baid--a.sjzlzbbh
 from yzsfw.bl_ecgsba a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10' and b.status='正在进行';

--施工单
select distinct b.wfinid--a.sjzlzbbh
 from yzsfw.bl_sgtzzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10';



---收费通知单
select distinct b.wfinid--a.tzdzt,count(distinct a.tzdid)--a.sjzlzbbh
 from yzsfw.bl_sftzdzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10'  group by a.tzdzt;


---点志记
select *
 from yzsfw.bl_dzjzb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid
where b.wfid='10';


---水表移交
select distinct b.wfinid--count(distinct cb.sbbjbid)
 from yzsfw.bl_sbyjzb a
 join wf_task k on a.taskid=k.taskid
 join bl_sbyjcb cb on a.sbyjdbh=cb.sbyjdbh
join yzsfw.wf_instance b on k.wfinid=b.wfinid
where b.wfid='10';


----附件表   工商科的设计成果
select * from bl_fjb t
join wf_instance a on t.wfinid=a.wfinid;



-----附件表  受理时候的附件在这里
select * from bl_fjzb t
join bl_fjcb a on t.fjid=a.fjid 
join wf_instance ins on t.wfinid=ins.wfinid
order by t.czsj desc;
end;
/

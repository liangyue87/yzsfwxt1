CREATE function get_gxcz_str(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select MC into Result from XTGL_GXCZ t where t.BH=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

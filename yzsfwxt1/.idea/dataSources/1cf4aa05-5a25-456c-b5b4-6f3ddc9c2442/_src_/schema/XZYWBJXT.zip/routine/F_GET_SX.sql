CREATE function f_get_sx(v_begintime date, v_min number)
  return date as
  --------获取时限结束时间
  resultdate date; --返回的值

  begintime date;
  endtime   date;
  begin_sfm varchar2(20);
  end_sfm   varchar2(20);

  alldays  number; -----整天的天数
  firstday number; -----第一天工作日
  lastday  number; -----最后一天工作日

  countxx number; ----第一天是否休息
  countsb number; ----第一天是否上班

  xxdays   number; -----周一到周五休息天数
  fjdays   number; -------周六周日上班天数
  zcxxdays number; ------正常休息天数 周六周日

  swsbsj varchar2(20); ----上午上班时间
  swxbsj varchar2(20); ----上午下班时间
  xwsbsj varchar2(20); ----下午上班时间
  xwxbsj varchar2(20); ----下午下班时间

  swsbdate date; ----上午上班时间
  swxbdate date; ----上午下班时间
  xwsbdate date; ----下午上班时间
  xwxbdate date; ----下午下班时间

  counthours number; ----一天上班的总小时数

begin


exception
  when others then
    begin
      return sysdate;
    end;
end;
/

CREATE function f_get_azlx_str(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select CODENAME into Result from Xtgl_Code t where t.CODEVALUE=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

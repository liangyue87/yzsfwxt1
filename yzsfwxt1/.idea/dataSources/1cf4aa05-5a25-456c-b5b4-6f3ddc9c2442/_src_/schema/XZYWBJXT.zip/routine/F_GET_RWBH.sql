CREATE function f_get_rwbh(v_key varchar2,v_value varchar2)
---获取单据编号 通过task表中数据
  return varchar2 as
  Result varchar2(50);
begin

  if v_key is null then
    return '';
  end if;
  if v_value is null then
    return '';
  end if;

  if(upper(v_key)='YWSL_CHGZSQB') then
    select nvl(t.sqbh,'') into Result from YWSL_CHGZSQB t where t.id=v_value;
  elsif(upper(v_key)='YWSL_GSHBSQB') then
    select nvl(t.sqbh,'') into Result from YWSL_GSHBSQB t where t.id=v_value;
  elsif(upper(v_key)='YWSL_XJXQSQB') then
    select nvl(t.sqbh,'') into Result from YWSL_XJXQSQB t where t.id=v_value;
  elsif(upper(v_key)='XCKC_RWZB') then
    select nvl(t.sqlb,'') into Result from XCKC_RWZB t where t.id=v_value;
  elsif(upper(v_key)='SJST_RWB') then
    select nvl(t.fqr,'') into Result from SJST_RWB t where t.id=v_value;
  elsif(upper(v_key)='YS_RWZB') then
    select nvl(t.xmid,'') into Result from YS_RWZB t where t.id=v_value;
  elsif(upper(v_key)='SGXT_RWB') then
    select nvl(t.rwbh,'') into Result from SGXT_RWB t where t.id=v_value;
  elsif(upper(v_key)='ZHYS_SQZB') then
    select nvl(t.rwbh,'') into Result from ZHYS_SQZB t where t.id=v_value;
  elsif(upper(v_key)='ZHYS_RWZB') then
    select nvl(t.rwbh,'') into Result from ZHYS_RWZB t where t.id=v_value;
  elsif(upper(v_key)='YJ_BWYJZB') then
    select nvl(t.bwyjdbh,'') into Result from YJ_BWYJZB t where t.id=v_value;
  elsif(upper(v_key)='YHJS_RWZB') then
    select nvl(t.rwbh,'') into Result from YHJS_RWZB t where t.id=v_value;
  elsif(upper(v_key)='YHJS_RWZB') then---设计结算表没设计
    select nvl(t.rwbh,'') into Result from YHJS_RWZB t where t.id=v_value;
  end if;
  
  
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

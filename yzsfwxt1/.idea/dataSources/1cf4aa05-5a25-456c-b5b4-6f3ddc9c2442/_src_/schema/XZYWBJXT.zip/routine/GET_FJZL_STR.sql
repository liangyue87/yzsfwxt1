CREATE function get_fjzl_str(v_code varchar2)
  return varchar2 as
  Result varchar2(150);
begin

  if v_code is null then
    return '';
  end if;
  select NAME into Result from xtgl_fjzlgl t where t.id=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

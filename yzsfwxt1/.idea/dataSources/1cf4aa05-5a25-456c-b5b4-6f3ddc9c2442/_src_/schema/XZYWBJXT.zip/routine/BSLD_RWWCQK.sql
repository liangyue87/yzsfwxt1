CREATE procedure BSLD_RWWCQK(v_begindate IN DATE,v_enddate IN DATE,p_cur out sys_refcursor) AS

begin

 --先判断全局临时表是否存在，没存在则重新建立：
    select count(*) into tmpcount from user_tables where table_name=upper('rwwcltj_temp');
    if tmpcount = 0 then
      --创建临时表暂存数据
      tmpsql2 := 'create global temporary table  rwwcltj_temp(
              ) on commit preserve rows';
      execute immediate tmpsql2; --创建临时表
    end if;
 open p_cur for select * from dual;
end;
/

CREATE procedure Get_XmZlqj(v_xmid IN varchar,v_yjlx IN varchar,p_cur out sys_refcursor) AS
--------资料全景
tmpcount int;
tmpsql2 string(2000);
vc2Comment string(2000);
slds int;
slhs int;
lxsl int;
lxhs int;
xdhs int;
yjhs int;
begindate date;
enddate date;
begin

    --返回临时表
    open p_cur for 'select t.id, t.name codename, t.parentid, count(a.id) count
  from XTGL_FJZLGL t
  left join SJST_YHZL a
    on t.id = a.fjlx_yj
   and a.xmid = '''||v_xmid||'''
   and a.sc_flag = 0
 where t.id = ''yhtgzl''
 group by t.id, t.name, t.parentid
 union all
 select t.id, t.name codename, t.parentid, count(a.id) count
  from XTGL_FJZLGL t
  left join XM_SLFJ a
    on t.id = a.fjlx_yj
   and a.xmid = '''||v_xmid||'''
   and a.sc_flag = 0
 where t.id = '''||v_yjlx||'''
 group by t.id, t.name, t.parentid
 union all
select a.id, a.name codename, a.parentid, count(c.id) count
  from XTGL_FJZLGL a
  left join XM_SLFJ c
    on a.id = c.fjlx_ej
   and c.xmid = '''||v_xmid||'''
   and c.sc_flag = 0
 where a.parentid = '''||v_yjlx||'''
 group by a.id, a.name, a.parentid
 union all
 select a.id, a.name codename, a.parentid, count(c.id) count
  from XTGL_FJZLGL a
  left join SJST_YHZL c
    on a.id = c.fjlx_ej
   and c.xmid = '''||v_xmid||'''
   and c.sc_flag = 0
 where a.parentid = ''yhtgzl''
 group by a.id, a.name, a.parentid
 union all

select t.id, t.name codename, t.parentid, count(c.id) count
  from XTGL_FJZLGL t
  left join (select * from YS_RWFJ a where a.YSRWID in (select b.id from YS_RWZB b where b.xmid = '''||v_xmid||''' and b.YSZT<4 ) and a.sc_flag = 0)c
    on t.id = c.fjlx_yj
 where t.id = ''wtys''
 group by t.id, t.name, t.parentid
  union all
select t.id, t.name codename, t.parentid, count(c.id) count
  from XTGL_FJZLGL t
  left join (select * from ht_qdzbfj a where a.HTQDID in (select b.id from HT_QDZB b where b.xmid = '''||v_xmid||''' and b.qdzt<2) and a.sc_flag = 0)c
    on t.id = c.fjlx_yj
 where t.id = ''htqd''
 group by t.id, t.name, t.parentid
  union all
select t.id, t.name codename, t.parentid, count(a.id) count
  from XTGL_FJZLGL t
  left join SJST_RW_SJSTCG a
    on t.id = a.fjlx_yj
   and a.sc_flag = 0
   and a.xmid = '''||v_xmid||'''
 where t.type = ''sjcg''
 group by t.id, t.name, t.parentid
  union all
select t.id, t.name codename, t.parentid, count(a.id) count
  from XTGL_FJZLGL t
  left join SJST_RW_SJSTCG a
    on t.id = a.fjlx_ej
   and a.sc_flag = 0
   and a.xmid = '''||v_xmid||'''
 where t.parentid in (select id from XTGL_FJZLGL where type=''sjcg'')
 group by t.id, t.name, t.parentid';
/* 关联施工*/
/* select t.id, t.name codename, t.parentid, count(c.id) count
  from XTGL_FJZLGL t
  left join (select * from SGXT_BGXX_FJ a where a.SGXT_BGXXID in (select b.id from SGXT_RWB b where b.xmid = '''||v_xmid||''' and b.ZT<2 ) and a.sc_flag = 0)c
    on t.id = c.fjlx_yj
 where t.id = ''sgzl''
 group by t.id, t.name, t.parentid
 union all*/
    --return;
        /*异常处理*/
    EXCEPTION
      WHEN OTHERS THEN
      ROLLBACK;

      --异常日志
      --vc2Comment:=SQLCODE || SUBSTR(SQLERRM,1,1023);
      vc2Comment:=sqlerrm;
           insert into calc_pro_log(type,sj,message) values('统计资料全景',sysdate,vc2Comment);
           commit;
   end;
/

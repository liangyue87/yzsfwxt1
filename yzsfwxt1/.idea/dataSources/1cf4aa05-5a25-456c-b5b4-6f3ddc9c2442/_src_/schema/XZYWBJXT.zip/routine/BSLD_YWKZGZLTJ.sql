CREATE procedure BSLD_YWKZGZLTJ(v_begindate IN DATE,v_enddate IN DATE,p_cur out sys_refcursor) AS
--------本期业务开展工作量（按时段）ywfl  1 居民科 2 工商科 3 户改科     暂时没统计 hhlx HB DB WJJLB
tmpcount int;
tmpsql2 string(2000);
vc2Comment string(2000);
slds int;
slhs int;
lxsl int;
lxhs int;
xdhs int;
yjhs int;
i_count int;
begindate date;
enddate date;
begin
 if(v_begindate is null) then
  begindate:=add_months(sysdate,-1);
 else
  begindate:=v_begindate;
 end if;
 if(v_enddate is null) then
  enddate:=sysdate+1;
  else
  enddate:=v_enddate+1;
 end if;

 --先判断全局临时表是否存在，没存在则重新建立：
    select count(*) into tmpcount from user_tables where table_name='YWKZGZL_TEMP';
    if tmpcount = 0 then
      --创建临时表暂存数据
      tmpsql2 := 'create global temporary table YWKZGZL_TEMP(
              ywfl int,
              hhlx varchar2(12),
              bqslds int,
              bqslhs int,
              bqlxs int,
              bqlxhs int,
              bqxds int,
              bqxdhs int,
              bqxdabl number(12,2),
              bqyjhs int,
              bqyjl number(12,2)
              ) on commit preserve rows';
      execute immediate tmpsql2; --创建临时表
    end if;

    --使用临时表前先清空
    execute immediate 'truncate table YWKZGZL_TEMP';
    ---将3个科室插入到表
    execute immediate 'insert into YWKZGZL_TEMP(ywfl)values(1)';
    execute immediate 'insert into YWKZGZL_TEMP(ywfl)values(2)';
    execute immediate 'insert into YWKZGZL_TEMP(ywfl)values(3)';

    ---本期受理单数
    select count(1) into slds from ywsl_chgzsqb t where t.slrq >begindate and t.slrq <enddate;
    --tmpsql2:= 'update YWKZGZL_TEMP set bqslds='||slds||' where ywfl=3';
    execute immediate 'update YWKZGZL_TEMP set bqslds='||slds||' where ywfl=3';

    select count(1) into slds from ywsl_gshbsqb t where t.slrq >begindate and t.slrq <enddate;
    execute immediate 'update YWKZGZL_TEMP set bqslds='||slds||' where ywfl=2';

    select count(1) into slds from ywsl_xjxqsqb t where t.slrq >begindate and t.slrq <enddate;
    execute immediate 'update YWKZGZL_TEMP set bqslds='||slds||' where ywfl=1';



     ---本期受理户数
     select count(1) into i_count from ywsl_chgzsqb t where t.slrq >begindate and t.slrq <enddate;
     if(i_count>0) then
     select nvl(t.lfhs,0)+nvl(t.pfhs,0) into slhs from ywsl_chgzsqb t where t.slrq >begindate and t.slrq <enddate;
     execute immediate 'update YWKZGZL_TEMP set bqslhs='||slhs||' where ywfl=3';
     else
       execute immediate 'update YWKZGZL_TEMP set bqslhs=0 where ywfl=3';
     end if;

     select count(1) into i_count from ywsl_gshbsqb t where t.slrq >begindate and t.slrq <enddate;
     if(i_count>0) then
      select nvl(YXAZSL,0) into slhs from ywsl_gshbsqb t where t.slrq >begindate and t.slrq <enddate;
       execute immediate 'update YWKZGZL_TEMP set bqslhs='||slhs||' where ywfl=2';
     else
       execute immediate 'update YWKZGZL_TEMP set bqslhs=0 where ywfl=2';
     end if;


     select count(1) into i_count from  ywsl_xjxqsqb t where t.slrq >begindate and t.slrq <enddate;
     if(i_count>0) then
     select nvl(HS,0) into slhs from ywsl_xjxqsqb t where t.slrq >begindate and t.slrq <enddate;
     execute immediate 'update YWKZGZL_TEMP set bqslhs='||slhs||' where ywfl=1';
     else
       execute immediate 'update YWKZGZL_TEMP set bqslhs=0 where ywfl=1';
     end if;



     ---本期立项数
    select count(1) into lxsl from xm_instance a
    where a.lxsj >begindate and a.lxsj <enddate and a.sqlx='30';
    execute immediate 'update YWKZGZL_TEMP set bqlxs='||lxsl||' where ywfl=3';

    select count(1) into lxsl from xm_instance a
    where a.lxsj >begindate and a.lxsj <enddate and a.sqlx='20';
    execute immediate 'update YWKZGZL_TEMP set bqlxs='||lxsl||' where ywfl=2';

    select count(1) into lxsl from xm_instance a
    where a.lxsj >begindate and a.lxsj <enddate and a.sqlx='10';
    execute immediate 'update YWKZGZL_TEMP set bqlxs='||lxsl||' where ywfl=1';


    ---本期立项户数
    select count(1) into lxhs from xm_instance a join xm_sb t on t.xm_id=a.id
    where t.slrq >begindate and t.slrq <enddate and a.sqlx='30';
    execute immediate 'update YWKZGZL_TEMP set bqlxhs='||lxhs||' where ywfl=3';

    select count(1) into lxhs from xm_instance a join xm_sb t on t.xm_id=a.id
    where t.slrq >begindate and t.slrq <enddate and a.sqlx='20';
    execute immediate 'update YWKZGZL_TEMP set bqlxhs='||lxhs||' where ywfl=2';

    select count(1) into lxhs from xm_instance a join xm_sb t on t.xm_id=a.id
    where t.slrq >begindate and t.slrq <enddate and a.sqlx='10';
    execute immediate 'update YWKZGZL_TEMP set bqlxhs='||lxhs||' where ywfl=1';



    ---本期下单户数
    select count(sb.id) into xdhs from xm_instance a join sgxt_rwb t on t.xmid=a.id join sgxt_rw_sb sb on t.id=sb.sgxdrwid
    where t.fqrq >begindate and t.fqrq <enddate and a.sqlx='30';
    execute immediate 'update YWKZGZL_TEMP set bqxdhs='||xdhs||' where ywfl=3';

    select count(1) into xdhs from xm_instance a join sgxt_rwb t on t.xmid=a.id join sgxt_rw_sb sb on t.id=sb.sgxdrwid
    where t.fqrq >begindate and t.fqrq <enddate and a.sqlx='20';
    execute immediate 'update YWKZGZL_TEMP set bqxdhs='||xdhs||' where ywfl=2';

    select count(1) into xdhs from xm_instance a join sgxt_rwb t on t.xmid=a.id join sgxt_rw_sb sb on t.id=sb.sgxdrwid
    where t.fqrq >begindate and t.fqrq <enddate and a.sqlx='10';
    execute immediate 'update YWKZGZL_TEMP set bqxdhs='||xdhs||' where ywfl=1';

    ---本期下单率
    execute immediate 'update YWKZGZL_TEMP set bqxdabl=case when bqlxhs>0 then round((bqxdhs*100/bqlxhs),2) end';


    ---本期下单户数
    select count(sb.id) into yjhs from xm_instance a join yj_sbyjzb t on t.xmid=a.id join yj_sbyjcb sb on t.id=sb.sbyjzbid
    where t.shsj >begindate and t.shsj <enddate and a.sqlx='30';
    execute immediate 'update YWKZGZL_TEMP set bqyjhs='||yjhs||' where ywfl=3';

    select count(1) into yjhs from xm_instance a join yj_sbyjzb t on t.xmid=a.id join yj_sbyjcb sb on t.id=sb.sbyjzbid
    where t.shsj >begindate and t.shsj <enddate and a.sqlx='20';
    execute immediate 'update YWKZGZL_TEMP set bqyjhs='||yjhs||' where ywfl=2';

    select count(1) into yjhs from xm_instance a join yj_sbyjzb t on t.xmid=a.id join yj_sbyjcb sb on t.id=sb.sbyjzbid
    where t.shsj >begindate and t.shsj <enddate and a.sqlx='10';
    execute immediate 'update YWKZGZL_TEMP set bqyjhs='||yjhs||' where ywfl=1';

    ---本期移交率
    execute immediate 'update YWKZGZL_TEMP set bqyjl=case when bqlxhs>0 then round((bqyjhs*100/bqlxhs),2) end';


    --返回临时表
    open p_cur for 'select * from YWKZGZL_TEMP';
    return;
        /*异常处理*/
    EXCEPTION
      WHEN OTHERS THEN
      ROLLBACK;

      --异常日志
      --vc2Comment:=SQLCODE || SUBSTR(SQLERRM,1,1023);
      vc2Comment:=sqlerrm;
           insert into calc_pro_log(type,sj,message) values('计算本期业务量统计',sysdate,vc2Comment);
           commit;
   end;
/

CREATE procedure ybh_yjjl(v_XMID IN VARCHAR2,v_Type IN VARCHAR2,i_result out VARCHAR2) is
/* --------------------------------------
获取默认选择指派人员
v_Type 1 设计人员 2 区所 select sys_guid() from dual;
----------------------------------------*/
v_exception  varchar2(1000);
i_count int;
tempresult varchar2(36);
i_pxmid varchar2(36);

begin
  ---数据迁移步骤
---3种受理数据
---1.居民科受理数据 
 insert into ywsl_xjxqsqb
       (id, sqbh, xmmc, kfsmc, dchs, gchs, lxr, lxrsjh, slr, slrq, bgr, bgsj, bgnr, bz, xzqybh, fpzt, fpr, 
  xmjl, xmdz_xzqybh, xmdz)
select id,b.sqbh,b.xmmc, kfsmc,dchs, gchs, a.lxr, a.lxrsjh, a.zdr,slrq, bgr, bgsj, bgnr,bz,b.xzqybh,2,'',b.xmfzr,b.xzqybh,
b.xmdz
 from yzsfw.bl_hbsqb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid;
---2.地表申请表
insert into ywsl_gshbsqb
  (id, sqbh, xmmc, lxr, lxrsjh, slr, slrq, bgr, bgsj, bgnr, bz, xmjl, 
  xmdz_xzqybh, xmdz, xzqybh, dwmc)
select a.id,b.sqbh,b.xmmc,b.lxr,b.lxrsjh,b.SLRBH,a.SLRQ,a.bgr,a.bgsj,a.bgnr,a.bz,b.xmfzr,
a.xzqybh,b.xmdz,a.xzqybh,b.dwmc
 from yzsfw.bl_dbsqb a
join yzsfw.wf_instance b on a.wfinid=b.wfinid;
---3.出户改造申请
/*insert into ywsl_gshbsqb
  (id, sqbh, xmmc, lxr, lxrsjh, yxazsl, jsyt, yhxz, yhh, ybkj, yxazkj, slr, slrq, bgr, bgsj, bgnr, bz, fpzt, fpr, fpsj, xmjl, xmdz_sheng, xmdz_shi, xmdz_xzqybh, xmdz, azlx, sqly, xzqybh, dwmc, yhhh, yhhm, sbkj, sblx)
select id, wfinid, dyzbhh, ldzbhh, xmmc, xysfs, xyszk, xhxzk, lxr, lxrsjh, lfhs, pfhs, pfds, lfds, zgcs, xfyss, ckyss, cpyss, mmyss, gcyss, wyyss, qtyss, slrq, zdr, bgr, bgsj, bgnr, bgzt, bz, txdz, dyzbxh, ldzbxh, dwmc, lxdh from yzsfw.bl_chsqb;*/
  ----4项目表同步
insert into xm_instance
  (id, pxmid, xmbh, sqlx,status, slrbh, lxsj, xmfzr, xmmc, lxr, lxrsjh, xmdz, dwmc, slsj, iszj, lxdh, xzqybh, sjfzr, stfzr, jlfzr, zjfzr, ysfzr, qsfzr, sgfzr, bz, bmbm_qs, xmdz_xzqybh)
select a.wfinid,a.wfzid,a.sqbh,a.wfid,a.status,a.slrbh,a.operation,a.xmfzr,a.xmmc,a.lxr,a.lxrsjh,a.xmdz,a.dwmc,a.slsj,a.iszj,a.lxdh,a.xzqybh,a.sjfzr,a.stfzr,a.jlfzr,a.zjfzr,'',a.qsfzr,a.sgfzr,'',a.bmbm_qs,a.xzqybh
  from yzsfw.wf_instance a; 
  ---5。附件同步
/*insert into xm_slfj
  (id, xmid, fjlx_yj, fjlx_ej, fjlj, fjhz, fjmc, scr, scsj, sc_flag, shcr, shcsj, sfgd, gdr, gdsj)
values
  (v_id, v_xmid, v_fjlx_yj, v_fjlx_ej, v_fjlj, v_fjhz, v_fjmc, v_scr, v_scsj, v_sc_flag, v_shcr, v_shcsj, v_sfgd, v_gdr, v_gdsj);
select * from bl_zlzb t
join bl_zlzb a on t.fjid=a.fjid 
join c_wjfl b on a.wjflbh=b.bh;*/

-----6.官网调查主表
insert into xckc_fk_qs
  (id, kcrwcbid, dcnr, gxzl, gxld, gxjzl, gxzzl, gxzsf, gxkj, gxcz, cydx, cysj, dcdwz, cydbg, cydyl, gwyj, bwts, dcr, dcrq, cjr, cjsj)
select a.id,'old',dcnr, gxzl, gxld, gxjzl, gxzzl, gxzsf, gxkj, gxcz, cydx, cysj, dcdwz, cydbg, cydyl, gwyj, bwts, dcr, dcrq,dcr, dcrq
 from yzsfw.BL_GWDCDCB a;
 
 ---7.设计审图不需要拿 很早的时候使用
---8.预算
---9收费通知单主表
 insert into sfkp_sftzdzb
   (id, tzdbh, xmid, ytzdbh, tzdzt, zhmc, zhyh, zh, ysje, jmje, ssje, zdr, zdsj, jfdw, pjlx, pjh, jfqrr, jfqrsj, bz, jmlx, skrq, skbz, jfje, xmqk, zbjcwfl, printed, jfqrrbmbh, qrjzrq)
select 
   tzdid,tzdid, wfinid, ytzdid, tzdzt, zhmc, zhyh, zh, ysje, jmje, ssje, zdr, zdsj, jfdw, pjlx, pjh, jfqrr, jfqrsj, bz, jmlx, skrq, skbz, jfje, xmqk, zbjcwfl, printed, jfqrrbmbh, qrjzrq from yzsfw.bl_sftzdzb;
---10收费通知单从表
 insert into sfkp_sftzdcb
   (id, sftzdzbid, tzdlx, ssje, ysje, jmje, jmlx,        zdr, zdsj, wjfsgsm, wjfsgsqld, bz)
select sys_guid(), tzdid, tzdlx, ssje, ysje, jmje, jmlx, zdr, zdsj, wjfsgsm, wjfsgsqld, bz from yzsfw.bl_sftzdcb;
commit;
----11收费通知单从表明细 正式库没有数据
--insert into sfkp_sftzdcbmx
 -- (id, sftzdcbid, kjbh, xdsl, sldw, gwjsfdj, gwjsfje, gcfdj, gcfje, ysxzbh, hyflbh, jbfsbh, hbyhlxbh)
---select sys_guid(),tzdid, tzdlx, xh, kjbh, pzsl, bjsl, sldw, gwjsfdj, gwjsfje, gcfdj, gcfje, ysxzbh, hyflbh, jbfsbh, jffsbh, hm, zbdz, yt, jbfs, dczt, bz, hbyhlxbh from yzsfw.bl_sftzdcbmx
----12收费通知单从表水表
insert into sfkp_sftzdcbsb
        (id, sftzdcbid, tzdlx, sbid,sblxbh, ldid, ssje, ysje, jmje, jfje, zzaz)
select sys_guid(), a.id, t.tzdlx, t.sbbjbid, t.hhlxbh, t.ldid, t.ssje, t.ysje, t.jmje, t.jfje, t.zzaz from yzsfw.bl_sftzdsb t
join sfkp_sftzdcb a on t.tzdid=a.sftzdzbid;
   ---13。预算附件同步
 /*insert into xm_slfj
  (id, xmid, fjlx_yj, fjlx_ej, fjlj, fjhz, fjmc, scr, scsj, sc_flag, shcr, shcsj, sfgd, gdr, gdsj)
values
  (v_id, v_xmid, v_fjlx_yj, v_fjlx_ej, v_fjlj, v_fjhz, v_fjmc, v_scr, v_scsj, v_sc_flag, v_shcr, v_shcsj, v_sfgd, v_gdr, v_gdsj);
select * from bl_zlzb t
join bl_zlzb a on t.fjid=a.fjid 
join c_wjfl b on a.wjflbh=b.bh;*/

-----14.施工下单主表 老流程和新流程不一样
insert into sgxt_rwb
        (id, rwbh, xmid, fqr, fqrq, zt,shr, shrq,shzt)
select sys_guid(),sbsgdbh, wfinid, pdr, pdsj,sgdzt,shr,shsj,shzt from (
 select distinct t.sbsgdbh, a.wfinid, pdr, pdsj,sgdzt,shr,shsj,shzt from yzsfw.bl_sbsgzb t
join yzsfw.wf_task a on t.sbsgdbh = a.sbsgdbh);
commit;

-----15.施工下单从表 
insert into sgxt_rw_sb
  (id, sgxdrwid, type, sbid, ldid)
   select sys_guid(), a.id, hhlxbh,sbbjbid,ldid from yzsfw.bl_sbsgcb t
   join sgxt_rwb a on t.sbsgdbh=a.rwbh;
   
---16.综合验收  老系统没有

---17.水表移交 主表
insert into yj_sbyjzb
  (id, sbyjdbh,xmid, yjdzt, xgsj, shr, shsj, shzt, jdr, jdsj, sfdc, cjr, cjsj)
select sys_guid(),sbyjdbh, wfinid, yjdzt,  xgsj, shr, shsj, shzt, jdr, jdsj, sfdc, CZR, cjsj from (
 select distinct t.sbyjdbh, a.wfinid, yjdzt,  xgsj, shr, shsj, shzt, jdr, jdsj, sfdc, a.CZR, cjsj from yzsfw.bl_sbyjzb t
join yzsfw.wf_task a on t.sbyjdbh = a.sbyjdbh);
commit;

---18.水表移交 从表
insert into yj_sbyjcb
  (id, sbyjzbid, sbyjdbh, sbid, hhlxbh, ldid)
select sys_guid(),a.id, t.sbyjdbh, sbbjbid, hhlxbh, ldid from yzsfw.bl_sbyjcb t
join yj_sbyjzb a on t.sbyjdbh=a.sbyjdbh;


---19.表位移交 主表
insert into yj_bwyjzb
           (id, bwyjdbh, xmid, bwyjdzt, cjsj, jdr, jdsj, jdbm, yjfsbh, yysj, qsysry, qsrysj)
select bwyjdbh,bwyjdbh,wfinid, bwyjdzt, cjsj, jdr, jdsj, jdbm, yjfsbh, yysj, qsysry, qsrysj from yzsfw.bl_bwyjzb;
commit;

---20.表位移交 从表

insert into yj_bwyjcb
              (id, bwyjdid, bwyjdbh, dzjid, dzjbh, shr, shsj, shzt, zt, jsyy, gf_shr, gf_shsj, gf_shzt, gf_jsyy)
select sys_guid(), bwyjdbh, bwyjdbh,dzjbh,dzjbh, shr, shsj, shzt, zt, jsyy, gf_shr, gf_shsj, gf_shzt, gf_jsyy from  yzsfw.bl_bwyjcb;
commit;


/*insert into yj_dzjzb
  (id, dzjbh, xmid, dzjlxbh, lm, ggmcbh, jgkjbh, azrq, czrq, czr, htr, zt, fbjj,  fmbh, sbbjbid, xhsbh, gdkjbh, gdczbh, ldid)
select  dzjbh,dzjbh, wfinid, dzjlxbh, lm, ggmcbh, jgkjbh, azrq, czrq, czr, htr, zt, tpid from yzsfw.bl_dzjzb;
commit;*/

---21 项目阀门
insert into xm_fm
        (id, fmbh, xmid, fmyxbh, azwz, azrq, fmkjbh, fmlxbh, fmcj, fmxh, fgfs, 
        fgsd, fgczbh, zdfsbh, zdfxbh, qbzs, fmzybh, fjgczbh, fjgxsbh, gps, czsj, czr, bz, zt, sbid)
select fmbh,fmbh, wfinid, fmyxbh, azwz, azrq, fmkjbh, fmlxbh, fmcj, fmxh, fgfs, 
fgsd, fgczbh, zdfsbh, zdfxbh, qbzs, fmzybh, fjgczbh, fjgxsbh, gps, czsj, czr, bz, zt, sbbjbid from yzsfw.bl_fm;

---22 项目消火栓
insert into xm_xhs
         (id, xhsbh, xmid, xhsyxbh, azwz, azrq, xhscj, xhbh, azfsbh, gps, czsj, czr, bz, zt, sbid)
select xhsbh,xhsbh, wfinid, xhsyxbh, azwz, azrq, xhscj, xhbh, azfsbh, gps, czsj, czr, bz, zt, sbbjbid from yzsfw.bl_xhs;
commit;




----项目范围获取
----1.庭院
insert into xm_ty
  (id, xmid, bh, mc)
select sys_guid(),a.wfinid,t.tybh,t.tymc from yzsfw.bl_ty t 
join yzsfw.bl_xmty a on t.tybh=a.tybh;
commit;

----2.楼栋
insert into xm_ld
  (id, xmid, tyid, ldbh, lfsx,dz, ldmc,ldzbhh,ldlgyz, ghhs)
select ldid, wfinid, a.id, lfsx, dz,  ldh,ldzbhh, tybh,ldlgyz, ghhs from yzsfw.bl_ld t 
join xm_ty a on t.tybh=a.bh;

insert into xm_ldfq
  (id, xmid, ldid, fqbh, qslc, zdlc, sybz)
select sys_guid(), wfinid, ldid, fqbh, qslc, zdlc, sybz from yzsfw.bl_ldfq;

update xm_ldfq t set t.fqmc = (select a.fqmc from xtgl_fq a where a.fqbh=t.fqbh);

----3.泵房
insert into xm_bf
  (id, xmid, bh, mc)
select sys_guid(),a.wfinid,t.bfbh,t.bfmc from yzsfw.bl_bf t 
join yzsfw.bl_xmbf a on t.bfbh=a.bfbh;
commit;


----4.水箱
insert into xm_sx
  (id, xmid, bfid, sxbh, sxmc, cd, kd, gd, rj, bz)
select sys_guid(),a.wfinid,b.id,t.sxbh, sxmc, cd, kd, gd, rj, a.bz from yzsfw.bl_sx t
join yzsfw.bl_xmsx a on t.sxbh=a.sxbh
join xm_bf b on t.bfbh=b.bh;

----5.地下室
insert into xm_dxs
  (id, xmid, bh, mc)
select sys_guid(),a.wfinid,t.dxsbh,t.dxsmc from yzsfw.bl_dxs t 
join yzsfw.bl_xmdxs a on t.dxsbh=a.dxsbh;
----6.水表
insert into xm_sb
  (id, xm_id, gcid, ldid, jffsbh, hhlxbh, ysxzbh, kjbh, zjlxbh, ykjbh, sqid, xh, hh, hm, dz, mph, type, kj, ds, 
  ysxz, khyh, khmc, yhzh, yhh, yhm, ydz, ybkj, ybds, ysbcj, ysqcm, bzlb, sfzh, lxr, lxdh, sbcj, yqwcrq, sjwcrq, bch, gznr, gzyy, 
  sgdw, czry, bz, bk, wtdw, slrq, zdr, azwz, azfs, sbje, gwjsfysje, gcfysje, sfxd, xdrq, sgsj, hbyhlxbh, zsljf, bsm, tssj, yssj, 
  gwjsfssje, gwjsfjmje, gwjsfzt, gcfzt, hyflbh, pqbh, sbsgbh, sfwg, yt, jbfs, azwzxzq, sgry, sgryqzsj, yhqr, yhqrqzsj, yyzx_xcyjrq, yyzx_sbds, 
  yyzx_sbkj, yyzx_bsm, yyzx_ysxzbh, yyzx_hyflbh, yyzx_sgry, yyzx_gssry, yyzx_yyzxry, yyzx_cbsflsfw, yyzx_bz, xfys, sfyj, sbcjbh, sgdw_sbkj, sfxdyj, 
  xdyjrq, dxfw, dxmc, dxhm, wfinid_hbsq, dbpzbh, dbpzcbid, zt, sblxbh, fq, yyzx_hh, gslxbh, gps, sbsxyz, xhsyz, cnxh, fqbh, zbwgsj, yjwcsj, bmbm_zb, bmbm_qs)
select id, wfinid, gcid, ldid, jffsbh, hhlxbh, ysxzbh, kjbh, zjlxbh, ykjbh, sqid, xh, hh, hm, dz, mph, type, kj, ds, 
ysxz, khyh, khmc, yhzh, yhh, yhm, ydz, ybkj, ybds, ysbcj, ysqcm, bzlb, sfzh, lxr, lxdh, sbcj, yqwcrq, sjwcrq, bch, gznr, gzyy, 
sgdw, czry, bz, bk, wtdw, slrq, zdr, azwz, azfs, sbje, gwjsfysje, gcfysje, sfxd, xdrq, sgsj, hbyhlxbh, zsljf, bsm, tssj, yssj, gwjsfssje, 
gwjsfjmje, gwjsfzt, gcfzt, hyflbh, pqbh, sbsgbh, sfwg, yt, jbfs, azwzxzq, sgry, sgryqzsj, yhqr, yhqrqzsj, yyzx_xcyjrq, yyzx_sbds, yyzx_sbkj, 
yyzx_bsm, yyzx_ysxzbh, yyzx_hyflbh, yyzx_sgry, yyzx_gssry, yyzx_yyzxry, yyzx_cbsflsfw, yyzx_bz, xfys, sfyj, sbcjbh, sgdw_sbkj, sfxdyj, xdyjrq, 
dxfw, dxmc, dxhm, wfinid_hbsq, dbpzbh, dbpzcbid, zt, sblxbh, fq, yyzx_hh, gslxbh, gps, sbsxyz, xhsyz, cnxh, fqbh, zbwgsj, yjwcsj, 
bmbm_zb, bmbm_qs from yzsfw.bl_sbbjb;
commit;

  exception
      when others then
        begin
          --记录日志
           v_exception:=sqlerrm;

           i_result:='';
        end;
end ybh_yjjl;
/

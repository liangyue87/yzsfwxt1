CREATE function f_get_activityname(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select activityname into Result from wf_df_activity t where t.activityid=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

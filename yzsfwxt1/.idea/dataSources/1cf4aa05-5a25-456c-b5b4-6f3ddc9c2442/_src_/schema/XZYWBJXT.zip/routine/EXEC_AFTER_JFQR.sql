CREATE procedure Exec_After_Jfqr(v_tzdid IN Varchar2) AS
--------缴费确认后执行 1.将表的缴费状态置为已缴费 2.缴费的表产生营销户号
--------执行需要地方：A。EAS接口确认缴费后 B。项目经理通过页面确认费用
tmpcount int;
tmpsql2 string(2000);
vc2Comment string(2000);
type cursor_value is ref cursor;
value_cur cursor_value;
i_sbid string(100);
i_count int;
i_bzlb int;
i_yyxhh string(100);
begin
   if(v_tzdid is null) then
      return;
   end if;

   ----修改费用状态
   --update xm_sb t set t.
   ----生成营销系统户号
     open value_cur for 'select c.sbid from sfkp_sftzdzb a
                          join sfkp_sftzdcb b on a.id=b.sftzdzbid
                          join sfkp_sftzdcbsb c on b.id=c.sftzdcbid
                          join xm_sb sb on c.sbid=sb.id
                          where a.id='''||v_tzdid||''' and c.sblxbh=''HB'' and sb.yyzx_hh is null order by sb.MPH,sb.LDID';
    loop
        fetch value_cur into i_sbid;
       exit when value_cur%notfound;
         p_get_yxxthh('HBHH',i_yyxhh);
          update xm_sb t set t.yyzx_hh = i_yyxhh where t.id=i_sbid and t.zt=0;
          commit;
     end loop;
     close value_cur;

   open value_cur for 'select c.sbid,c.bzlb from sfkp_sftzdzb a
                          join sfkp_sftzdcb b on a.id=b.sftzdzbid
                          join sfkp_sftzdcbsb c on b.id=c.sftzdcbid
                          where a.id='''||v_tzdid||''' and c.sblxbh=''DB'' and sb.yyzx_hh is null order by sb.MPH';
    loop
        fetch value_cur into i_sbid,i_bzlb;
       exit when value_cur%notfound;
       if(i_bzlb=1) then
         p_get_yxxthh('GSBHH',i_yyxhh);
          update xm_sb t set t.yyzx_hh = i_yyxhh where t.id=i_sbid and t.zt=0;
          commit;
        else
         -----移改表的工商表 户号不变
         update xm_sb t set t.yyzx_hh = t.yhh where t.id=i_sbid and t.zt=0;
          commit;
       end if;
     end loop;
     close value_cur;

        /*异常处理*/
    EXCEPTION
      WHEN OTHERS THEN
      ROLLBACK;

      --异常日志
      --vc2Comment:=SQLCODE || SUBSTR(SQLERRM,1,1023);
      vc2Comment:=sqlerrm;
           insert into calc_pro_log(type,sj,message) values('缴费确认执行',sysdate,vc2Comment);
           commit;
   end;
/

CREATE procedure get_zyzb_jcsj_calc(v_begintime date,
                                                   v_endtime date,
                                                   icyclekind integer,
                                                   iweekly integer) as
    p_begindate date;
    p_enddate   date;
    v_exception  varchar2(1000);
    i_slds int;
    i_slhs int;
    i_lxsl int;
    i_lxhs int;
    i_xdhs int;
    i_yjhs int;
    i_count int;
    i_tbhs int;
begin
    p_begindate := v_begintime;
    p_enddate   := v_endtime+1;

      ----先删除
      delete from tjfx_wc_jcsj t where t.zqsz=iweekly and t.kssj=p_begindate and t.jszq = icyclekind;
      commit;
      ---将3个科室插入到表
      insert into tjfx_wc_jcsj
        (id, jszq, zqsz, kssj, jssj, ywlx)
      values(sys_guid(),icyclekind,iweekly,p_begindate,p_enddate,'10');
      insert into tjfx_wc_jcsj
        (id, jszq, zqsz, kssj, jssj, ywlx)
      values(sys_guid(),icyclekind,iweekly,p_begindate,p_enddate,'20');
      insert into tjfx_wc_jcsj
        (id, jszq, zqsz, kssj, jssj, ywlx)
      values(sys_guid(),icyclekind,iweekly,p_begindate,p_enddate,'30');
      commit;

      -------本期受理  受理数  户数
      select count(1) into i_slds from ywsl_chgzsqb t where t.slrq >p_begindate and t.slrq <p_enddate;
      update tjfx_wc_jcsj t set slds=i_slds where ywlx='30' and t.jszq= icyclekind and t.kssj =p_begindate;

      select count(1) into i_slds from ywsl_gshbsqb t where t.slrq >p_begindate and t.slrq <p_enddate;
      update tjfx_wc_jcsj t set slds=i_slds where ywlx='20' and t.jszq= icyclekind and t.kssj =p_begindate;

      select count(1) into i_slds from ywsl_xjxqsqb t where t.slrq >p_begindate and t.slrq <p_enddate;
      update tjfx_wc_jcsj t set slds=i_slds where ywlx='10' and t.jszq= icyclekind and t.kssj =p_begindate;
      commit;

      ---本期受理户数
     select count(1) into i_count from ywsl_chgzsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
     if(i_count>0) then
     select nvl(t.lfhs,0)+nvl(t.pfhs,0) into i_slds from ywsl_chgzsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
     update tjfx_wc_jcsj set slhs=i_slds where ywlx='30' and jszq= icyclekind and kssj =p_begindate;
     else
       update tjfx_wc_jcsj set slhs=0 where ywlx='30' and jszq= icyclekind and kssj =p_begindate;
     end if;

     select count(1) into i_count from ywsl_gshbsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
     if(i_count>0) then
      select nvl(YXAZSL,0) into i_slds from ywsl_gshbsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
       update tjfx_wc_jcsj set slhs=i_slds where ywlx='20' and jszq= icyclekind and kssj =p_begindate;
     else
      update tjfx_wc_jcsj set slhs=0 where ywlx='20' and jszq= icyclekind and kssj =p_begindate;
     end if;


     select count(1) into i_count from  ywsl_xjxqsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
     if(i_count>0) then
     select nvl(HS,0) into i_slds from ywsl_xjxqsqb t where t.slrq >p_begindate and t.slrq <p_begindate;
     update tjfx_wc_jcsj set slhs=i_slds where ywlx='10' and jszq= icyclekind and kssj =p_begindate;
     else
      update tjfx_wc_jcsj set slhs=0 where ywlx='10' and jszq= icyclekind and kssj =p_begindate;
     end if;
      commit;

      ---勘察完成  按实际到场时间计算
      update tjfx_wc_jcsj tt set tt.kcwc=(
      select count(1) from xckc_rwzb t
      join xm_xckc_rela rela on t.id=rela.xckcid
      join xm_instance a on a.id=rela.xmid
      where t.sjdcrq >p_begindate and t.sjdcrq <p_enddate and t.kczt<6 and tt.ywlx=a.sqlx
       and tt.jszq= icyclekind and tt.kssj =p_begindate
      group by a.sqlx);
      commit;

      ----项目立项数
      update tjfx_wc_jcsj tt set tt.xmlxs=(
      select count(1) from xm_instance a
      where a.lxsj >p_begindate and a.lxsj <p_enddate and tt.ywlx=a.sqlx
      and tt.jszq= icyclekind and tt.kssj =p_begindate
      group by a.sqlx);
      commit;

      ---本期立项户数
      update tjfx_wc_jcsj tt set tt.xmlxhs=(
      select count(1) from xm_instance a join xm_sb t on t.xm_id=a.id
      where t.slrq >p_begindate and t.slrq <p_enddate and tt.ywlx=a.sqlx
      and tt.jszq= icyclekind and tt.kssj =p_begindate
      group by a.sqlx);
      commit;

      ---同比 户数 %  只计算月的 其他的同比使用时再说
      select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='10';
        if(i_count>0) then
          select xmlxhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='10';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xmhstbzz=xmlxhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='10';
          commit;
        end if;

        select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='20';
        if(i_count>0) then
          select xmlxhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='20';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xmhstbzz=xmlxhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='20';
          commit;
        end if;

        select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='30';
        if(i_count>0) then
          select xmlxhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='30';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xmhstbzz=xmlxhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='30';
          commit;
        end if;
         ---设计完成  按设计结束时间计算
        update tjfx_wc_jcsj tt set tt.sjstwc=(
        select count(1) from sjst_rwb t
        join xm_sjst_rela rela on t.id=rela.sjstid
        join xm_instance a on a.id=rela.xmid
        where t.sjjssj >p_begindate and t.sjjssj <p_enddate and t.sjstzt >0 and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;

          ---预算完成  按结束时间计算
        update tjfx_wc_jcsj tt set tt.yswc=(
        select count(1) from ys_rwzb t
        join xm_instance a on a.id=t.xmid
        where t.ysjssj >p_begindate and t.ysjssj <p_enddate and t.yszt <4 and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        ---预算完成金额
        update tjfx_wc_jcsj tt set tt.yswcje=(
        select sum(cb.ysje) from ys_rwzb t
        join ys_rwcb cb on t.id=cb.ysrwzbid
        join xm_instance a on a.id=t.xmid
        where t.ysjssj >p_begindate and t.ysjssj <p_enddate and t.yszt <4 and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;

        ----合同签订份数
       update tjfx_wc_jcsj tt set tt.htqdfs=(
        select count(1) from ht_qdzb t
        join xm_instance a on a.id=t.xmid
        where t.htqdsj >p_begindate and t.htqdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;

        ----合同签订户数  同立项户数
        update tjfx_wc_jcsj tt set tt.htqdhs = tt.xmlxhs where tt.jszq= icyclekind and tt.kssj =p_begindate;
        commit;
        ---合同签订金额
        /*update tjfx_wc_jcsj tt set tt.yswcje=(
        select sum(t.gczje)+sum(cb.gczje) from ht_qdzb t
        join ht_qdcb cb on t.id=cb.htqdid
        join xm_instance a on a.id=t.xmid
        where t.ysjssj >p_begindate and t.ysjssj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;*/

        ----费用收取
        ----缴费通知单到账数量 金额
        update tjfx_wc_jcsj tt set tt.jfddzsl=(select count(1) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt=1 and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);

        update tjfx_wc_jcsj tt set tt.jfddzje=(select round(sum(t.ysje)/10000,2) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt=1 and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);
       commit;
       ----开票数量  开票金额 开票未到账金额
       update tjfx_wc_jcsj tt set tt.kpsl=(select count(1) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.pjh is not null and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);

        update tjfx_wc_jcsj tt set tt.kpje=(select round(sum(t.jfje)/10000,2) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.pjh is not null and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);
       commit;

       -----开票 未到账确认情况
        update tjfx_wc_jcsj tt set tt.kpwdzsl=(select count(1) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt=0 and t.pjh is not null and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);

        update tjfx_wc_jcsj tt set tt.kpwdzje=(select round(sum(t.jfje)/10000,2) from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt=0 and t.pjh is not null and t.zdsj>p_begindate and t.zdsj <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq = icyclekind and tt.kssj = p_begindate
        group by a.sqlx);
       commit;
       ----下单户数
        update tjfx_wc_jcsj tt set tt.xdhs=(
        select count(1) from sgxt_rwb t
        join xm_instance a on a.id=t.xmid
        join sgxt_rw_sb sb on t.id=sb.sgxdrwid
        where t.fqrq >p_begindate and t.fqrq <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        
        ----下单涉及项目数      
        update tjfx_wc_jcsj tt set tt.xdsjxms=(
        select count(distinct a.id) from sgxt_rwb t
        join xm_instance a on a.id=t.xmid
        join sgxt_rw_sb sb on t.id=sb.sgxdrwid
        where t.fqrq >p_begindate and t.fqrq <p_enddate and tt.ywlx=a.sqlx
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
         ---同比 户数 %  
      select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='10';
        if(i_count>0) then
          select xdhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='10';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xdhstb_zzl=xdhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='10';
          commit;
        end if;

        select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='20';
        if(i_count>0) then
          select xdhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='20';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xdhstb_zzl=xdhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='20';
          commit;
        end if;

        select count(1) into i_count from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj =add_months(p_begindate,-12) and t.ywlx='30';
        if(i_count>0) then
          select xdhs into i_tbhs from tjfx_wc_jcsj t where t.jszq= icyclekind and t.kssj = add_months(p_begindate,-12) and t.ywlx='30';
          end if;
          if(i_tbhs>0) then
          update tjfx_wc_jcsj t set t.xdhstb_zzl=xdhs-i_tbhs, t.xmhstb_zzl=round(((xmlxhs-i_tbhs)/i_tbhs),2) where t.jszq = icyclekind and t.kssj = p_begindate  and t.ywlx='30';
          commit;
        end if;
        
        ---通水户数  以施工单位填写为准
        
        ---通水涉及项目数
        
        ---综合验收户数
        ---综合验收涉及项目数
        update tjfx_wc_jcsj tt set tt.zhyssjxms=(
        select count(distinct a.id) from zhys_rwzb t
        join xm_instance a on a.id=t.xmid
        where t.sjyssj >p_begindate and t.sjyssj <p_enddate and tt.ywlx=a.sqlx and t.fkjg=1
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        ---用户结算笔数  以用户确认为准 
        update tjfx_wc_jcsj tt set tt.yjhs=(
        select count(1) from yhjs_rwzb t
        join xm_instance a on a.id=t.xmid
        where t.yhqrsj >p_begindate and t.yhqrsj <p_enddate and tt.ywlx=a.sqlx and t.zt=1
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        
        ----用户结算金额
        update tjfx_wc_jcsj tt set tt.yjhs=(
        select sum(nvl(b.jsje,0)) from yhjs_rwzb t
        join xm_instance a on a.id=t.xmid
        join yhjs_rwcb b on t.id=b.yhjsrwzbid
        where t.yhqrsj >p_begindate and t.yhqrsj <p_enddate and tt.ywlx=a.sqlx and t.zt=1
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        ---移交户数
        update tjfx_wc_jcsj tt set tt.yjhs=(
        select count(1) from yj_sbyjzb t
        join xm_instance a on a.id=t.xmid
        join yj_sbyjcb sb on t.id=sb.sbyjzbid
        where t.shsj >p_begindate and t.shsj <p_enddate and tt.ywlx=a.sqlx and t.shzt=1
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;
        ---移交涉及项目数
        update tjfx_wc_jcsj tt set tt.yjsjxms=(
        select count(distinct a.id) from yj_sbyjzb t
        join xm_instance a on a.id=t.xmid
        join yj_sbyjcb sb on t.id=sb.sbyjzbid
        where t.shsj >p_begindate and t.shsj <p_enddate and tt.ywlx=a.sqlx and t.shzt=1
         and tt.jszq= icyclekind and tt.kssj =p_begindate
        group by a.sqlx);
        commit;


     exception
      when others then
        begin
          --记录日志
           v_exception:=sqlerrm;
           insert into calc_pro_log(type,sj,message) values('计算重要指标明细',sysdate,v_exception);
           commit;
         rollback;
        end;
end;
/

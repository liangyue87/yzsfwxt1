CREATE function f_get_sjhm(v_account varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_account is null then
    return '';
  end if;
  select mobilephone into Result from xtgl_user t where t.userid=v_account;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

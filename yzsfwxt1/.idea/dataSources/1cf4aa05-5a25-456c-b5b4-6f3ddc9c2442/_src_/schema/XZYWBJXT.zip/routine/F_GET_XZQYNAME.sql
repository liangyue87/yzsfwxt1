CREATE function f_get_xzqyname(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select name into Result from xtgl_xzqy t where t.bh=v_code;
  return Result;


  exception
      when others then
        begin
             return v_code;
        end;
end;
/

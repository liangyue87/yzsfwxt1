CREATE function f_get_username(v_code varchar2)
  return varchar2 as
  Result varchar2(50);
begin

  if v_code is null then
    return '';
  end if;
  select USERNAME into Result from xtgl_USER t where t.USERID=v_code;
  return Result;


  exception
      when others then
        begin
             return '';
        end;
end;
/

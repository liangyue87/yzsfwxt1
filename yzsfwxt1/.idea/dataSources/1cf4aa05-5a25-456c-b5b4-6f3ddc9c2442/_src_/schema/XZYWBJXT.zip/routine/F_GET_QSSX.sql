CREATE function f_get_qssx(v_begintime date, v_min number)
  return date as
  --------获取签收时限结束时间
  resultdate date; --返回的值
  tempdate date;

  begintime date;
  endtime   date;
  begin_sfm varchar2(20);
  end_sfm   varchar2(20);

  alldays  number; -----整天的天数
  firstday number; -----第一天工作日
  lastday  number; -----最后一天工作日

  countxx number; ----第一天是否休息
  countsb number; ----第一天是否上班

  xxdays   number; -----周一到周五休息天数
  fjdays   number; -------周六周日上班天数
  zcxxdays number; ------正常休息天数 周六周日

  swsbsj varchar2(20); ----上午上班时间
  swxbsj varchar2(20); ----上午下班时间
  xwsbsj varchar2(20); ----下午上班时间
  xwxbsj varchar2(20); ----下午下班时间

  swsbdate date; ----上午上班时间
  swxbdate date; ----上午下班时间
  xwsbdate date; ----下午上班时间
  xwxbdate date; ----下午下班时间

  counthours number; ----一天上班的总小时数
  i_count number;
  j_count number;
  o_count number;

begin

   ----先查询到离开始时间最近的上班时间t.DAY = begintime  AND t.WORK = 0 and
   begintime:=v_begintime;
   tempdate:=v_begintime+1;
   WHILE begintime < tempdate Loop
         ----是周六或是周日
        select count(1) into i_count from dual where TO_CHAR(begintime, 'day') = '星期六' or TO_CHAR(begintime, 'day') = '星期日';
        if(i_count>0) then
            select count(1) into j_count from XTGL_WKCB t where t.DAY = begintime AND t.WORK = 1;
            if(j_count>0) then 
               tempdate:=begintime;
            else
                begintime:=trunc(begintime)+1;
                tempdate:=begintime+1;
            end if;
         else
             select count(1) into o_count from XTGL_WKCB t where t.DAY = begintime AND t.WORK = 0; 
             if(o_count=0) then 
               tempdate:=begintime;
             else
                begintime:=trunc(begintime)+1;
                tempdate:=begintime+1;
             end if;
        end if;
    END LOOP;

   

   SELECT MAX(T.AMS)
    into swsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= v_begintime;
  SELECT MAX(T.AMF)
    into swxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= v_begintime;
  SELECT MAX(T.PMS)
    into xwsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= v_begintime;
  SELECT MAX(T.PMF)
    into xwxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= v_begintime;


    swsbdate   := to_date(swsbsj, 'HH24:mi:ss');
    swxbdate   := to_date(swxbsj, 'HH24:mi:ss');
    xwsbdate   := to_date(xwsbsj, 'HH24:mi:ss');
    xwxbdate   := to_date(xwxbsj, 'HH24:mi:ss');
    ----
    begin_sfm := to_char(begintime, 'HH24:mi:ss');
    if to_date(begin_sfm, 'HH24:mi:ss') <= swsbdate then
       tempdate:=swsbdate+v_min/24/60;
       
    end if;
    
     
     
    

   return tempdate;

exception
  when others then
    begin
      return sysdate;
    end;
end;
/

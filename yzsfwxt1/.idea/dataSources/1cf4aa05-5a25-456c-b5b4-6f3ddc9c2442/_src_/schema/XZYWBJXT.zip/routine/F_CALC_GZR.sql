CREATE function f_calc_gzr(v_begintime date, v_endtime date)
  return number as
  ret number(8, 2); --返回的值

  begintime date;
  endtime   date;
  begin_sfm varchar2(20);
  end_sfm   varchar2(20);

  alldays  number; -----整天的天数
  firstday number; -----第一天工作日
  lastday  number; -----最后一天工作日

  countxx number; ----第一天是否休息
  countsb number; ----第一天是否上班

  xxdays   number; -----周一到周五休息天数
  fjdays   number; -------周六周日上班天数
  zcxxdays number; ------正常休息天数 周六周日

  swsbsj varchar2(20); ----上午上班时间
  swxbsj varchar2(20); ----上午下班时间
  xwsbsj varchar2(20); ----下午上班时间
  xwxbsj varchar2(20); ----下午下班时间

  swsbdate date; ----上午上班时间
  swxbdate date; ----上午下班时间
  xwsbdate date; ----下午上班时间
  xwxbdate date; ----下午下班时间

  counthours number; ----一天上班的总小时数

begin

  -----如果开始时间为空  返回0
  if v_begintime IS NULL then
    return 0;
  else
    begintime := trunc(v_begintime);
    begin_sfm := to_char(v_begintime, 'HH24:mi:ss');
  end if;
  ------------没有结束时间取当前时间
  if v_endtime IS NULL then
    endtime := sysdate;
    end_sfm := to_char(sysdate, 'HH24:mi:ss');
  else
    endtime := v_endtime;
    end_sfm := to_char(endtime, 'HH24:mi:ss');
  end if;
  ------------开始时间大于结束时间
  if (v_begintime > endtime) then
    return 0;
  end if;
  endtime := trunc(endtime);

  -------时间段内周一到周五休息的天数
  SELECT COUNT(1)
    into xxdays
    FROM XTGL_WKCB A
   WHERE A.DAY >= begintime
     AND A.DAY < endtime
     AND A.WORK = 0 and TO_CHAR(DAY, 'day') <> '星期六' and TO_CHAR(DAY, 'day') <> '星期日';
  -------时间段内周六周日上班的天数
  SELECT COUNT(1)
    into fjdays
    FROM XTGL_WKCB A
   WHERE A.DAY >= begintime
     AND A.DAY < endtime
     AND A.WORK = 1 and (TO_CHAR(DAY, 'day') = '星期六' or TO_CHAR(DAY, 'day') = '星期日');
  -------时间段内正常的周六周日
  SELECT COUNT(1)
    into zcxxdays
    FROM (SELECT begintime + LV - 1 DT
            FROM (SELECT LEVEL LV
                    FROM DUAL
                  CONNECT BY LEVEL <= TRUNC(endtime - begintime, 0)) TT) TM
   WHERE (TO_CHAR(TM.DT, 'day') = '星期六' OR
         TO_CHAR(TM.DT, 'day') = '星期日');

  SELECT COUNT(1)
    into countxx
    FROM XTGL_WKCB A
   WHERE A.DAY = begintime
     AND A.WORK = 0 and TO_CHAR(DAY, 'day') <> '星期六' and TO_CHAR(DAY, 'day') <> '星期日';

  SELECT COUNT(1)
    into countsb
    FROM XTGL_WKCB A
   WHERE A.DAY = begintime
     AND A.WORK = 1 and (TO_CHAR(DAY, 'day') = '星期六' or TO_CHAR(DAY, 'day') = '星期日');
  ----------第一天为休息的时候
  if (TO_CHAR(begintime, 'day') = '星期六' OR
     TO_CHAR(begintime, 'day') = '星期日' or countxx > 0) and countsb =0 then
    alldays := endtime - begintime + fjdays - xxdays - zcxxdays;
  elsif TO_CHAR(begintime, 'day') <> '星期六' and
        TO_CHAR(begintime, 'day') <> '星期日' and countsb = 0 and countxx>0 then
    alldays := endtime - begintime + fjdays - xxdays - zcxxdays;
  else
    ----第一天不休息
    alldays := endtime - begintime + fjdays - xxdays - zcxxdays - 1;
  end if;

  --------计算第一天的工作日

  SELECT MAX(T.AMS)
    into swsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= begintime
     AND T.JSSJ >= begintime;
  SELECT MAX(T.AMF)
    into swxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= begintime
     AND T.JSSJ >= begintime;
  SELECT MAX(T.PMS)
    into xwsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= begintime
     AND T.JSSJ >= begintime;
  SELECT MAX(T.PMF)
    into xwxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= begintime
     AND T.JSSJ >= begintime;

  SELECT COUNT(1)
    into countxx
    FROM XTGL_WKCB A
   WHERE A.DAY = begintime
     AND A.WORK = 0 and TO_CHAR(DAY, 'day') <> '星期六' and TO_CHAR(DAY, 'day') <> '星期日';

  SELECT COUNT(1)
    into countsb
    FROM XTGL_WKCB A
   WHERE A.DAY = begintime
     AND A.WORK = 1 and (TO_CHAR(DAY, 'day') = '星期六' or TO_CHAR(DAY, 'day') = '星期日');
  ----------第一天为休息的时候
  if (TO_CHAR(begintime, 'day') = '星期六' OR
     TO_CHAR(begintime, 'day') = '星期日' or countxx > 0) and countsb=0 then
    firstday := 0;
  elsif TO_CHAR(begintime, 'day') <> '星期六' and
        TO_CHAR(begintime, 'day') <> '星期日' and countsb = 0 and countxx>0 then
    firstday := 0;
  else
    swsbdate   := to_date(swsbsj, 'HH24:mi:ss');
    swxbdate   := to_date(swxbsj, 'HH24:mi:ss');
    xwsbdate   := to_date(xwsbsj, 'HH24:mi:ss');
    xwxbdate   := to_date(xwxbsj, 'HH24:mi:ss');
    counthours := (xwxbdate - xwsbdate + swxbdate - swsbdate) * 24;
    if (counthours = 0) then
      return 0;
    end if;
    if to_date(begin_sfm, 'HH24:mi:ss') <= swsbdate then
      firstday := 1;
    elsif to_date(begin_sfm, 'HH24:mi:ss') > swsbdate and
          to_date(begin_sfm, 'HH24:mi:ss') <= swxbdate then
      firstday := Round((swxbdate - to_date(begin_sfm, 'HH24:mi:ss') +
                        xwxbdate - xwsbdate) * 24 / counthours,
                        2);
    elsif to_date(begin_sfm, 'HH24:mi:ss') > swxbdate and
          to_date(begin_sfm, 'HH24:mi:ss') <= xwsbdate then
      firstday := Round((xwxbdate - xwsbdate) * 24 / counthours, 2);
    elsif to_date(begin_sfm, 'HH24:mi:ss') > xwsbdate and
          to_date(begin_sfm, 'HH24:mi:ss') <= xwxbdate then
      firstday := Round((xwxbdate - to_date(begin_sfm, 'HH24:mi:ss')) * 24 /
                        counthours,
                        2);
    elsif to_date(begin_sfm, 'HH24:mi:ss') > xwxbdate then
      firstday := 0;
    end if;

  end if;

  --------计算最后一天的工作日

  SELECT MAX(T.AMS)
    into swsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= endtime
     AND T.JSSJ >= endtime;
  SELECT MAX(T.AMF)
    into swxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= endtime
     AND T.JSSJ >= endtime;
  SELECT MAX(T.PMS)
    into xwsbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= endtime
     AND T.JSSJ >= endtime;
  SELECT MAX(T.PMF)
    into xwxbsj
    FROM XTGL_WKZB T
   WHERE T.KSSJ <= endtime
     AND T.JSSJ >= endtime;

  SELECT COUNT(1)
    into countxx
    FROM XTGL_WKCB A
   WHERE A.DAY = endtime
     AND A.WORK = 0 and TO_CHAR(DAY, 'day') <> '星期六' and TO_CHAR(DAY, 'day') <> '星期日';

  SELECT COUNT(1)
    into countsb
    FROM XTGL_WKCB A
   WHERE A.DAY = endtime
     AND A.WORK = 1 and (TO_CHAR(DAY, 'day') = '星期六' or TO_CHAR(DAY, 'day') = '星期日');
  ----------最后一天为休息的时候
  if (TO_CHAR(endtime, 'day') = '星期六' OR
     TO_CHAR(endtime, 'day') = '星期日' or countxx > 0) and countsb=0 then
    lastday := 0;
  elsif TO_CHAR(endtime, 'day') <> '星期六' and
        TO_CHAR(endtime, 'day') <> '星期日' and countsb = 0 and countxx>0 then
    lastday := 0;
  else
    swsbdate   := to_date(swsbsj, 'HH24:mi:ss');
    swxbdate   := to_date(swxbsj, 'HH24:mi:ss');
    xwsbdate   := to_date(xwsbsj, 'HH24:mi:ss');
    xwxbdate   := to_date(xwxbsj, 'HH24:mi:ss');
    counthours := (xwxbdate - xwsbdate + swxbdate - swsbdate) * 24;

    if (counthours = 0) then
      return 0;
    end if;

    if to_date(end_sfm, 'HH24:mi:ss') <= swsbdate then
      lastday := 0;
    elsif to_date(end_sfm, 'HH24:mi:ss') > swsbdate and
          to_date(end_sfm, 'HH24:mi:ss') <= swxbdate then
      lastday := Round((to_date(end_sfm, 'HH24:mi:ss') - swsbdate) * 24 /
                       counthours,
                       2);
    elsif to_date(end_sfm, 'HH24:mi:ss') > swxbdate and
          to_date(end_sfm, 'HH24:mi:ss') <= xwsbdate then
      lastday := Round((swxbdate - swsbdate) * 24 / counthours, 2);
    elsif to_date(end_sfm, 'HH24:mi:ss') > xwsbdate and
          to_date(end_sfm, 'HH24:mi:ss') <= xwxbdate then
      lastday := Round((to_date(end_sfm, 'HH24:mi:ss') - xwsbdate +
                       swxbdate - swsbdate) * 24 / counthours,
                       2);
    elsif to_date(end_sfm, 'HH24:mi:ss') > xwxbdate then
      lastday := 1;
    end if;

  end if;

  ret := alldays + firstday + lastday;
  return ret;

exception
  when others then
    begin
      return 0;
    end;
end;
/

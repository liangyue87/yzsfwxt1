CREATE function get_dzjmc(v_dzjid varchar2)
  return varchar2 as
  Result varchar2(150);
begin
 select 
case DZJLXBH when '01' then 
(CASE CB.DZJCBLXBH WHEN '03' THEN (SELECT decode(hhlxbh,'HB','居民报表','DB','工商表','五级计量表')|| sb.hh || 'Φ' || kj.mc FROM xm_sb sb
join xtgl_kj kj on sb.SGDW_SBKJ=kj.bh
 WHERE sb.id=CB.SBID) else null end)
|| '前阀Φ' || (CASE WHEN CB.DZJCBLXBH='01' THEN (SELECT kj.mc FROM XM_FM fm join xtgl_fmkj kj on fm.fmkjbh =kj.bh WHERE fm.id=CB.fmid) ELSE NULL END)
|| '后阀Φ' || (CASE WHEN CB.DZJCBLXBH='02' THEN (SELECT kj.mc FROM XM_FM fm join xtgl_fmkj kj on fm.fmkjbh =kj.bh WHERE fm.id=CB.fmid) ELSE NULL END)

when '02' then 
'阀门Φ' || (CASE WHEN CB.DZJCBLXBH='05' THEN (SELECT kj.mc FROM XM_FM fm join xtgl_fmkj kj on fm.fmkjbh =kj.bh WHERE fm.id=CB.fmid) ELSE NULL END)

when '03' then 
(CASE WHEN CB.DZJCBLXBH='04' THEN (SELECT '消火栓' || CASE WHEN X.SBID IS NOT NULL THEN decode(S.hhlxbh,'HB','居民报表','DB','工商表','五级计量表') || S.hh || 'Φ' || 
 kj.mc ELSE NULL END
FROM XM_XHS X JOIN xm_sb S ON X.sbid=S.id
join xtgl_kj kj on S.SGDW_SBKJ=kj.bh
 WHERE X.id=CB.XHSID)
  ELSE NULL END)
  
when '04' then 
CASE WHEN CB.DZJCBLXBH='06' THEN (select '高层' || LD.LDMC || '楼共' || NVL(T.HS,0) || '块' 
from XM_LD LD 
JOIN (SELECT SB.LDID, SUM(CASE WHEN ZT=1 THEN 1 ELSE 0 END) HS FROM XM_SB SB GROUP BY SB.LDID) T ON LD.ID=T.LDID
where CB.LDID=LD.Id)
ELSE NULL END
end into Result
 from yj_dzjzb t 
join yj_dzjcb CB on t.id=CB.dzjzbid
where t.id=v_dzjid;
 return Result;

  exception
      when others then
        begin
             return '';
        end;
end;
/

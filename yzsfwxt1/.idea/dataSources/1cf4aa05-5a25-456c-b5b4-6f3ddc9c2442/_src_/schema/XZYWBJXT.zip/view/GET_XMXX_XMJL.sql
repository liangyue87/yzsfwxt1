CREATE VIEW GET_XMXX_XMJL AS select '未立项' code,count(1) num ,xmjl from (
    select x.id,x.xmjl from YWSL_XJXQSQB x where x.sflx = '0'
    union all
    select c.id,c.xmjl from YWSL_CHGZSQB c where c.sflx = '0'
    union all
    select g.id,g.xmjl from YWSL_GSHBSQB g where g.sflx = '0'
    )
group by xmjl

union all

select '已立项' code,count(1) num,xmjl from (
       select xm.id,xm.xmfzr xmjl from XM_INSTANCE xm where xm.status = '1'
       )
group by xmjl

union all

select '有活动' code,count(1) num,xmjl from
(
select xm.id,xm.xmfzr xmjl from xm_instance xm left join Wf_Ru_Inst_Content ic on xm.id = ic.contentvalue
              join wf_ru_inst it on ic.proc_inst_id = it.proc_inst_id
              where xm.status = '1' and it.procstatus = '1' and  upper(ic.table_name) = 'XM_INSTANCE'

union all

select a.id,a.xmjl from YWSL_XJXQSQB a left join Wf_Ru_Inst_Content ic on a.id = ic.contentvalue
              join wf_ru_inst it on ic.proc_inst_id = it.proc_inst_id
              where a.sflx = '0' and it.procstatus = '1' and  upper(ic.table_name) = 'YWSL_XJXQSQ'

union all

select b.id,b.xmjl from YWSL_GSHBSQB b left join Wf_Ru_Inst_Content ic on b.id = ic.contentvalue
              join wf_ru_inst it on ic.proc_inst_id = it.proc_inst_id
              where b.sflx = '0' and it.procstatus = '1' and  upper(ic.table_name) = 'YWSL_GSHBSQB'

union all

select c.id,c.xmjl from YWSL_CHGZSQB c left join Wf_Ru_Inst_Content ic on c.id = ic.contentvalue
              join wf_ru_inst it on ic.proc_inst_id = it.proc_inst_id
              where c.sflx = '0' and it.procstatus = '1' and  upper(ic.table_name) = 'YWSL_GSHBSQB'
)
group by xmjl

union all

select '无活动'code,count(1) num,xmjl from (
    select xm.id,xm.xmfzr xmjl from xm_instance xm where not exists (
           select it.proc_inst_id from wf_ru_inst it left join wf_ru_inst_content ic on it.proc_inst_id = ic.proc_inst_id
           where it.procstatus = '1' and upper(ic.table_name) = 'XM_INSTANCE' and xm.id = ic.contentvalue
    )
    and xm.status = '1'

    union all

    select a.id,a.xmjl from YWSL_XJXQSQB a where not exists (
           select it.proc_inst_id from wf_ru_inst it left join wf_ru_inst_content ic on it.proc_inst_id = ic.proc_inst_id
           where it.procstatus = '1' and upper(ic.table_name) = 'YWSL_XJXQSQB' and a.id = ic.contentvalue
    )
    and a.sflx = '0'

    union all

    select b.id,b.xmjl from YWSL_GSHBSQB b where not exists (
           select it.proc_inst_id from wf_ru_inst it left join wf_ru_inst_content ic on it.proc_inst_id = ic.proc_inst_id
           where it.procstatus = '1' and upper(ic.table_name) = 'YWSL_XJXQSQB' and b.id = ic.contentvalue
    )
    and b.sflx = '0'

    union all

    select c.id,c.xmjl from YWSL_GSHBSQB c where not exists (
           select it.proc_inst_id from wf_ru_inst it left join wf_ru_inst_content ic on it.proc_inst_id = ic.proc_inst_id
           where it.procstatus = '1' and upper(ic.table_name) = 'YWSL_XJXQSQB' and c.id = ic.contentvalue
    )
    and c.sflx = '0'
)
group by xmjl

union all

select '未到账' code,count(1),xmfzr xmjl from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt = 0 and a.status= 1
       group by a.xmfzr

union all

select '已到账' code,count(1),xmfzr xmjl from sfkp_sftzdzb t join xm_instance a on a.id=t.xmid where t.tzdzt = 1 and a.status= 1
       group by a.xmfzr
/

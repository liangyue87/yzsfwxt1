CREATE VIEW YS_ZLXX AS select a.ID FJID,b.ID YSZBID,c.USERID,a.FJMC,a.FJHZ,to_char(a.SCSJ,'yyyy-mm-dd hh24:mi:ss') SCSJ, c.USERNAME,a.FJLJ
from (YS_RWFJ a inner join YS_RWZB b on a.YSRWID in b.ID) inner join  XTGL_USER c  on c.USERID in a.SCR
/

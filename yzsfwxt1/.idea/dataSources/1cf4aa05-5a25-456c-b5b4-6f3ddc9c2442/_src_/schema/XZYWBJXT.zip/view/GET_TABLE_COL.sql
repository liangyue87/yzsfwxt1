CREATE VIEW GET_TABLE_COL AS select b.TABLE_NAME,b.COLUMN_NAME,b.DATA_TYPE,c.comments from  user_tab_columns b
join user_col_comments c on b.COLUMN_NAME=c.column_name
/

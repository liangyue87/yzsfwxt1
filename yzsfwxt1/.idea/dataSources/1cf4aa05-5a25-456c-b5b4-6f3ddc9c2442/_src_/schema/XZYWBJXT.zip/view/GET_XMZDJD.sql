CREATE VIEW GET_XMZDJD AS with proc as (select t.contentvalue,a.pdef_id,'yx' proc_status from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE')

select "ID","XMFZR","SJHM","PDEF_ID" from (
select tt.id,tt.xmfzr,f_get_sjhm(tt.xmfzr) sjhm,max(pdef_id) pdef_id  from xm_instance tt join
proc p on tt.id=p.contentvalue
group by tt.id,tt.xmfzr,f_get_sjhm(tt.xmfzr))
/

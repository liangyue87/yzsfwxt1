CREATE VIEW GET_JFFYLX AS select c."ID",c."YSRWZBID",c."YSJE",c."YSJE_OLD",c."BZ",z.xmid,f.mc,f.bh YSFL,nvl(sc.ysje,0) ykdj,nvl(sb.ysje,0) ydz from xtgl_fylx f left join ys_rwcb c on c.ysfl = f.bh left join ys_rwzb z on c.ysrwzbid = z.id
 left join (select sz.xmid,sc.tzdlx,sum(sc.ysje) ysje from sfkp_sftzdcb sc left join sfkp_sftzdzb sz on sc.sftzdzbid = sz.id where sz.tzdzt = 0 group by sc.tzdlx,sz.xmid) sc
 on sc.tzdlx = c.ysfl and sc.xmid = z.xmid
 left join (select sz.xmid,sc.tzdlx,sum(sc.ysje) ysje from sfkp_sftzdcb sc left join sfkp_sftzdzb sz on sc.sftzdzbid = sz.id where sz.tzdzt = 1 group by sc.tzdlx,sz.xmid) sb
  on sb.tzdlx = c.ysfl and sb.xmid = z.xmid
/

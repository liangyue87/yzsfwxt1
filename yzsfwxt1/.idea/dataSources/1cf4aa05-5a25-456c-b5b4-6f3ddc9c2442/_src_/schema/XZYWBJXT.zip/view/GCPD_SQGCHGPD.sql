CREATE VIEW GCPD_SQGCHGPD AS with proc as (
  select t.contentvalue,a.pdef_id,t.proc_inst_id
  from wf_hi_inst_content t
  join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id
  join (select t.*, t.rowid from WF_RE_NODE t where  substr(t.activityid,0,1)='8') p on a.pdef_id=p.pdef_id
  where upper(t.table_name)='XM_INSTANCE'
）
select '0' pdzt,pc.pdef_id pdefid,pc.proc_inst_id procinstid,e."ID",e."PXMID",e."XMBH",e."SQLX",e."AZLX",e.codename,e."SLID",e."SQBH",e."XMLB",e."XMTZF",e."XMSWLXFL",e."QBID",e."STATUS",e."SLRBH",to_char(e.LXSJ,'yyyy-mm-dd hh24:mi:ss')lxsj,e."XMFZR",e."XMMC",e."LXR",e."LXRSJH",e."XMDZ",e."DWMC",to_char(e.SLSJ,'yyyy-mm-dd hh24:mi:ss')SLSJ,e."ISZJ",e."LXDH",e."XZQYBH",e."ZJZMJ",e."SJFZR",e."STFZR",e."JLFZR",e."ZJFZR",e."YSFZR",e."QSFZR",e."SGFZR",e."BZ",e."BMBM_QS",to_char(e.JHKSSJ,'yyyy-mm-dd hh24:mi:ss')JHKSSJ,to_char(e.JHJSSJ,'yyyy-mm-dd hh24:mi:ss')JHJSSJ,e."XMDZ_SHENG",e."XMDZ_SHI",e."XMDZ_XZQYBH",e."USERID",e."PXMBH",e."SLSJ_STR"
from  proc pc
left join (select e.*,d.CODENAME
    from xm_instance e
        left join XTGL_CODE d on e.AZLX = d.CODEVALUE) e  on pc.contentvalue=e.id
where e.status='1'
/

CREATE VIEW V_YJSB AS select x.xmbh,x.xmmc,u.username,y."ID",y."SBYJDBH",y."XMID",y."YJDZT",y."XGSJ",y."SHR",y."SHSJ",y."SHZT",y."JDR",y."JDSJ",y."SFDC",y."CJR",y."CJSJ",case when y.yjdzt = 0 then '待移交' when y.yjdzt = 1 then '移交中' when y.yjdzt = 2 then '已移交' else '作废' end yjzt
  from yj_sbyjzb y left join xm_instance x on y.xmid = x.id left join xtgl_user u on y.cjr = u.userid
/

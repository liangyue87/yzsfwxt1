CREATE VIEW YS_LDSH AS select b.ID yszbid, a.ID,  a.XMBH,a.STATUS,a.AZLX,a.LXR,a.LXRSJH,to_char(a.LXSJ,'yyyy-mm-dd hh24:mi:ss') LXSJ,a.XMMC,a.xmdz,a.DWMC,b.SFSH
from YS_RWZB b inner join XM_INSTANCE a on b.XMID = a.ID and b.YSZT= '3'
/

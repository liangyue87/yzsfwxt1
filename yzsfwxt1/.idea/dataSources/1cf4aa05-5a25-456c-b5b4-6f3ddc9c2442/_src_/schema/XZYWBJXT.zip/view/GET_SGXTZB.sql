CREATE VIEW GET_SGXTZB AS select x.xmbh,
       x.xmmc,
       s."ID",s."RWBH",s."XMID",s."FQR",s."FQRQ",s."GCNR_TY",s."GCNR_BF",s."GCNR_LG",s."GCNR_DG",s."GCNR_QT",s."XMGZRY",s."RWCLSJ",s."ZT",s."BZ",s."SHZT",s."THYY",
       u.username lxr,
       case
         when s.zt = 0 and s.shzt <> 2   then
          '未下单'
         when s.zt = 1 then
          '已下单'
         when s.zt = 2 then
          '作废'
         when s.shzt = 2 then
           '退回'
         else
          ''
       end rwzt,
       to_char(s.fqrq,'yyyy-MM-dd hh24:mi') cjsj,case when w.pdef_id is null then '0' when w.pdef_id = '70001' then '0' else '1' end lczt
  from sgxt_rwb s
  left join xm_instance x
    on s.xmid = x.id
  left join xtgl_user u
    on s.fqr = u.userid
  left join wf_ru_inst w on w.parammap = s.rwbh
/

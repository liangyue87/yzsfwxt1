CREATE VIEW YS_YSZY AS select a."USERID",a."ACCOUNT",a."PASSWORD",a."USERNAME",a."MOBILEPHONE",a."EMAIL",a."ISLOCKED",a."REGTIME",a."LASTLOGIN",a."ORGNUMBER",a."USERROLE",'' "ROLENAME"
from xtgl_user a
left join xtgl_userrole b on b.userid = a.userid
where b.roleid='f8621ce59de24e06b6d2f4d55569eda6'
/

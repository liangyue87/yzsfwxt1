CREATE VIEW GET_ALLTASK_WORK AS select tt.id xmid,p.proc_inst_id,w.C_ACTIVITYID,w.bjzt,case when nvl(w.check_time,sysdate)>w.check_sx then 1 else 0 end qssfcs,
w.check_time,w.qssj,w.jssj,w.jssx,case when nvl(w.jssj,sysdate)>w.jssx then 1 else 0 end sfhuangd,
case when nvl(w.jssj,sysdate)>w.jssx_yl then 1 else 0 end sfhongd,to_char(w.qssj,'yyyy-mm-dd hh24:mi:ss') qssj_str,
 to_char(w.jssj,'yyyy-mm-dd hh24:mi:ss') jssj_str,f_get_username(w.rwblr) rwblr_str
 from XM_INSTANCE tt
join get_allinst_work p on p.contentvalue=tt.id and upper(p.table_name) = 'XM_INSTANCE'
join get_all_task w on p.proc_inst_id=w.proc_inst_id

union all

select tt.id xmid,p.proc_inst_id,w.C_ACTIVITYID,w.bjzt,case when nvl(w.check_time,sysdate)>w.check_sx then 1 else 0 end qssfcs,
w.check_time,w.qssj,w.jssj,w.jssx,case when nvl(w.jssj,sysdate)>w.jssx then 1 else 0 end sfhuangd,
case when nvl(w.jssj,sysdate)>w.jssx_yl then 1 else 0 end sfhongd,to_char(w.qssj,'yyyy-mm-dd hh24:mi:ss') qssj_str,
  to_char(w.jssj,'yyyy-mm-dd hh24:mi:ss') jssj_str,f_get_username(w.rwblr) rwblr_str
 from YWSL_XJXQSQB tt
join get_allinst_work p on p.contentvalue=tt.id and upper(p.table_name) = 'YWSL_XJXQSQB'
join get_all_task w on p.proc_inst_id=w.proc_inst_id

union all

select tt.id xmid,p.proc_inst_id,w.C_ACTIVITYID,w.bjzt,case when nvl(w.check_time,sysdate)>w.check_sx then 1 else 0 end qssfcs,
w.check_time,w.qssj,w.jssj,w.jssx,case when nvl(w.jssj,sysdate)>w.jssx then 1 else 0 end sfhuangd,
case when nvl(w.jssj,sysdate)>w.jssx_yl then 1 else 0 end sfhongd,to_char(w.qssj,'yyyy-mm-dd hh24:mi:ss') qssj_str,
  to_char(w.jssj,'yyyy-mm-dd hh24:mi:ss') jssj_str,f_get_username(w.rwblr) rwblr_str
 from YWSL_GSHBSQB tt
join get_allinst_work p on p.contentvalue=tt.id and upper(p.table_name) = 'YWSL_GSHBSQB'
join get_all_task w on p.proc_inst_id=w.proc_inst_id

union all

select tt.id xmid,p.proc_inst_id,w.C_ACTIVITYID,w.bjzt,case when nvl(w.check_time,sysdate)>w.check_sx then 1 else 0 end qssfcs,
w.check_time,w.qssj,w.jssj,w.jssx,case when nvl(w.jssj,sysdate)>w.jssx then 1 else 0 end sfhuangd,
case when nvl(w.jssj,sysdate)>w.jssx_yl then 1 else 0 end sfhongd,to_char(w.qssj,'yyyy-mm-dd hh24:mi:ss') qssj_str,
  to_char(w.jssj,'yyyy-mm-dd hh24:mi:ss') jssj_str,f_get_username(w.rwblr) rwblr_str
 from YWSL_CHGZSQB tt
join get_allinst_work p on p.contentvalue=tt.id and upper(p.table_name) = 'YWSL_CHGZSQB'
join get_all_task w on p.proc_inst_id=w.proc_inst_id
/

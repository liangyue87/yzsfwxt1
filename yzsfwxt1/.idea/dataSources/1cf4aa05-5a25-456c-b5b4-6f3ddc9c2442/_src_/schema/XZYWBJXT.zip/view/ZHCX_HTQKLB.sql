CREATE VIEW ZHCX_HTQKLB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.fssj,t.qrsj,t.zt,t.qdny,t.gczje,t.htqdyfk,
round((t.htqdyfk/t.gczje),2)*100||'%' yfkbl,count(b.id) xyfs,sum(b.gczje) xyzje from ht_qdzb t
join xm_instance a on t.xmid=a.id
join ht_qdcb b on t.id=b.htqdid
group by a.id,a.xmbh,a.xmmc,a.xmfzr,t.fssj,t.qrsj,t.zt,t.qdny,t.gczje,t.htqdyfk,round((t.htqdyfk/t.gczje),2)*100||'%'
/

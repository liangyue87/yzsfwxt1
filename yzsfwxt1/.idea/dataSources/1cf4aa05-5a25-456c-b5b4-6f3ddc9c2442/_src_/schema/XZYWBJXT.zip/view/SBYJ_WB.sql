CREATE VIEW SBYJ_WB AS select s."ID",s."XM_ID",s."GCID",s."LDID",s."JFFSBH",s."HHLXBH",s."YSXZBH",s."KJBH",s."ZJLXBH",s."YKJBH",s."SQID",s."XH",s."HH",s."HM",s."DZ",s."MPH",s."TYPE",s."KJ",s."DS",s."YSXZ",s."KHYH",s."KHMC",s."YHZH",s."YHH",s."YHM",s."YDZ",s."YBKJ",s."YBDS",s."YSBCJ",s."YSQCM",s."BZLB",s."SFZH",s."LXR",s."LXDH",s."SBCJ",s."YQWCRQ",s."SJWCRQ",s."BCH",s."GZNR",s."GZYY",s."SGDW",s."CZRY",s."BZ",s."BK",s."WTDW",s."SLRQ",s."ZDR",s."AZWZ",s."AZFS",s."SBJE",s."GWJSFYSJE",s."GCFYSJE",s."SFXD",s."XDRQ",s."SGSJ",s."HBYHLXBH",s."ZSLJF",s."BSM",s."TSSJ",s."YSSJ",s."GWJSFSSJE",s."GWJSFJMJE",s."GWJSFZT",s."GCFZT",s."HYFLBH",s."PQBH",s."SBSGBH",s."SFWG",s."YT",s."JBFS",s."AZWZXZQ",s."SGRY",s."SGRYQZSJ",s."YHQR",s."YHQRQZSJ",s."YYZX_XCYJRQ",s."YYZX_SBDS",s."YYZX_SBKJ",s."YYZX_BSM",s."YYZX_YSXZBH",s."YYZX_HYFLBH",s."YYZX_SGRY",s."YYZX_GSSRY",s."YYZX_YYZXRY",s."YYZX_CBSFLSFW",s."YYZX_BZ",s."XFYS",s."SFYJ",s."SBCJBH",s."SGDW_SBKJ",s."SFXDYJ",s."XDYJRQ",s."DXFW",s."DXMC",s."DXHM",s."WFINID_HBSQ",s."DBPZBH",s."DBPZCBID",s."ZT",s."SBLXBH",s."FQ",s."YYZX_HH",s."GSLXBH",s."GPS",s."SBSXYZ",s."XHSYZ",s."CNXH",s."FQBH",s."ZBWGSJ",s."YJWCSJ",s."BMBM_ZB",s."BMBM_QS",c.codename vjffs,d.codename vysxz,e.mc vkjmc,f.mc vsgkjmc,g.codename vsblx,
             ROWNUM rn from xm_sb s
             left join sgxt_rw_sb a on s.id = a.sbid and s.hhlxbh = a.type left join sgxt_rwb w
             on a.sgxdrwid = w.id and s.xm_id = w.xmid
             left join (select * from xtgl_code c where c.parentid = (select id from xtgl_code where type = 'jffs')) c on s.jffsbh = c.codevalue
             left join (select * from xtgl_code d where d.parentid = (select id from xtgl_code where type = 'ysxz')) d on s.ysxzbh = d.codevalue
             left join xtgl_kj e on s.kjbh = e.bh
             left join xtgl_kj f on s.sgdw_sbkj = f.bh
             left join (select * from xtgl_code g where g.parentid = (select id from xtgl_code where type = 'sblx')) g on s.SBLXBH = g.codevalue
             where  s.hhlxbh = 'WJJLB'
/

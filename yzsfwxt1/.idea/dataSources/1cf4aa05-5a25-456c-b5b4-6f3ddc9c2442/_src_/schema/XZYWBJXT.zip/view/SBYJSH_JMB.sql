CREATE VIEW SBYJSH_JMB AS select m."XMID",m."ID",m."LDBH",nvl(m.bcyjs,0) bcyjs,nvl(n.yyjs,0) yyjs,nvl(p.wyjs,0) wyjs,(nvl(m.bcyjs,0)+nvl(n.yyjs,0)+nvl(p.wyjs,0)) zhs from
(select l.xmid,l.id,l.ldbh,count(1) bcyjs from xm_ld l left join yj_sbyjcb c on l.id=c.ldid left join yj_sbyjzb z on c.sbyjzbid = z.id and z.xmid = l.xmid where c.hhlxbh = 'HB' and z.yjdzt = 0
 group by l.xmid,l.id,l.ldbh) m
 left join
(select l.xmid,l.id,l.ldbh,count(1) yyjs from xm_ld l left join yj_sbyjcb c on l.id=c.ldid left join yj_sbyjzb z on c.sbyjzbid = z.id and z.xmid = l.xmid where c.hhlxbh = 'HB' and z.yjdzt = 1
 group by l.xmid,l.id,l.ldbh) n
 on m.xmid = n.xmid and m.id = n.id
 left join
(select l.xmid,l.id,l.ldbh,count(1) wyjs from xm_ld l left join xm_sb s on l.id = s.ldid where s.id in
 (select c.sbid from xm_ld l left join yj_sbyjcb c on l.id=c.ldid left join yj_sbyjzb z on c.sbyjzbid = z.id and z.xmid = l.xmid where c.hhlxbh = 'HB' and z.yjdzt = 0 or c.hhlxbh = 'HB' and z.yjdzt = 1)
  group by l.xmid,l.id,l.ldbh) p
 on m.xmid = p.xmid and m.id = p.id
/

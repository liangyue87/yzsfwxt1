CREATE VIEW ZHCX_TFTZDLB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.tzdbh,t.ytje,t.stje,t.qrsj,t.sjh,t.qrsj zt from tf_rwb t
join xm_instance a on t.xmid=a.id
/

CREATE VIEW GET_XCKC_FQ AS select '0' lxzt,sqbh xmbh,sqbh,'10' type, a.id,a.lxr,a.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'0' rwzt from ywsl_xjxqsqb a
where not exists(select sqid from xckc_rwzb where sqlb = '10'  and a.id = sqid) and a.sflx = '0' and a.fpzt in ('1','2') or  a.id in (select sqid from xckc_rwzb where sqlb = '10' and kczt = '6')
and not exists(select sqid from xckc_rwzb where sqlb = '10' and kczt <6 and a.id = sqid)
union all
select '0' lxzt,sqbh xmbh,sqbh,'20' type,b.id,b.lxr,b.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'0' rwzt from ywsl_gshbsqb b
where not exists(select sqid from xckc_rwzb where sqlb = '20' and b.id = sqid) and b.sflx = '0'  and b.fpzt in ('1','2') or  b.id in (select sqid from xckc_rwzb where sqlb = '10' and kczt = '6')
and not exists(select sqid from xckc_rwzb where sqlb = '20' and kczt <6 and b.id = sqid)
union all
select '0' lxzt,sqbh xmbh,sqbh,'30' type,c.id,c.lxr,c.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'0' rwzt from ywsl_chgzsqb c
where not exists(select sqid from xckc_rwzb where sqlb = '30' and c.id =sqid) and c.sflx = '0' and c.fpzt in ('1','2') or  c.id in (select sqid from xckc_rwzb where sqlb = '10' and kczt = '6')
and not exists(select sqid from xckc_rwzb where sqlb = '30' and kczt <6 and  c.id = sqid)
union all
select '1' lxzt,d.xmbh,sqbh, f_get_name(d.azlx) type,d.id,d.lxr,d.lxrsjh,xmfzr,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz,slrbh slr,to_char(slsj,'yyyy-mm-dd') slrq,xzqybh,'0' rwzt from xm_instance d
where not exists(select a.xmid from xm_xckc_rela a left join xckc_rwzb b on a.xckcid = b.id where b.kczt  <6 and d.id = a.xmid)
and not exists(select sqid from xckc_rwzb where kczt <6 and d.qbid = sqid)
and pxmid is not null
union all
select '0' lxzt,sqbh xmbh,sqbh,'10' type, a.id,a.lxr,a.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'1' rwzt from ywsl_xjxqsqb a
where  exists (select sqid from xckc_rwzb where sqlb = '10' and kczt not in (4,5,6) and a.id = sqid) and a.sflx = '0'  and a.fpzt in ('1','2')
union all
select '0' lxzt,sqbh xmbh,sqbh,'20' type,b.id,b.lxr,b.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'1' rwzt from ywsl_gshbsqb b
where exists (select sqid from xckc_rwzb where sqlb = '20' and kczt not in (4,5,6) and  b.id = sqid) and b.sflx = '0' and b.fpzt in ('1','2')
union all
select '0' lxzt,sqbh xmbh,sqbh,'30' type,c.id,c.lxr,c.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq,xzqybh,'1' rwzt from ywsl_chgzsqb c
where exists (select sqid from xckc_rwzb where sqlb = '30' and kczt not in (4,5,6) and c.id = sqid) and c.sflx = '0' and c.fpzt in ('1','2')
union all
select '1' lxzt,d.xmbh,sqbh, f_get_name(d.azlx) type,d.id,d.lxr,d.lxrsjh,xmfzr,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz,slrbh slr,to_char(slsj,'yyyy-mm-dd') slrq,xzqybh,'1' rwzt from xm_instance d
where exists (select a.xmid from xm_xckc_rela a left join xckc_rwzb b on a.xckcid = b.id where b.kczt not in ('4','5','6') and d.id = a.xmid)
and pxmid is not null
/

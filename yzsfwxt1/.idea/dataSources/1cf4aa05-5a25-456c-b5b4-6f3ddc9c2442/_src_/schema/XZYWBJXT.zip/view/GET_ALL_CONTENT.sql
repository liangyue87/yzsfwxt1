CREATE VIEW GET_ALL_CONTENT AS select contentid, proc_inst_id, table_name, contentremark, contentname, contenttype, readonly, contentvalue from wf_hi_inst_content
union all
select contentid, proc_inst_id, table_name, contentremark, contentname, contenttype, readonly, contentvalue from wf_ru_inst_content
/

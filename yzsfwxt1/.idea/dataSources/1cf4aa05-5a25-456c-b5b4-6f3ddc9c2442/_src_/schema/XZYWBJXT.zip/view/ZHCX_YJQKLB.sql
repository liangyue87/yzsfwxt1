CREATE VIEW ZHCX_YJQKLB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.cjr,'水表移交' yjlx,t.cjsj yjkssj,t.shsj yjwcsj,t.shr jsr  from yj_sbyjzb t
join xm_instance a on t.xmid=a.id
union all
select a.id,a.xmbh,a.xmmc,a.xmfzr,t.cjr,'表位移交' yjlx,t.cjsj yjkssj,t.yjwcsj,t.qsysry jsr  from yj_bwyjzb t
join xm_instance a on t.xmid=a.id
/

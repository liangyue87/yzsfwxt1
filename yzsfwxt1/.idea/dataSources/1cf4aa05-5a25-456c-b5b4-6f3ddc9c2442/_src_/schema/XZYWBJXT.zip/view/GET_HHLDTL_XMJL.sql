CREATE VIEW GET_HHLDTL_XMJL AS select t.xmjl,count(case t.qssfcs when 1 then 1 else 0 end)+count(case t.sfhongd when 1 then 1 else 0 end) hongddbsl,
count(case t.sfhuangd when 1 then 1 else 0 end) huangddbsl,
count(case when t.qssfcs+t.sfhuangd+t.sfhongd=0 then 1 else 0 end) lddbsl,
count(case t.qssfcs when 1 then 1 else 0 end)+count(case t.sfhongd when 1 then 1 else 0 end)+count(case t.sfhuangd when 1 then 1 else 0 end)+count(case when t.qssfcs+t.sfhuangd+t.sfhongd=0 then 1 else 0 end) zdbsl
 from get_wdrw_dblb t
group by t.xmjl
/

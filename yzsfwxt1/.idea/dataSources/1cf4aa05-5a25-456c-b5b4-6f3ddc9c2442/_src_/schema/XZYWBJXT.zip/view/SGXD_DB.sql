CREATE VIEW SGXD_DB AS select x.id,x.hh,x.hm,x.dz,x.kj,x.mph,'wxd' type,h.codename hyflname,y.codename ysxzname,j.codename jffsname,x.xm_id from xm_sb x
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'hyfl')) h on h.codevalue = x.hyflbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'ysxz')) y on y.codevalue = x.ysxzbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'jffs')) j on j.codevalue = x.jffsbh
              where x.HHLXBH = 'DB' and x.id not in
              (select distinct sbid from sgxt_rw_sb where sbid is not null)
             union all
              select x.id,x.hh,x.hm,x.dz,x.kj,x.mph,'dxd' type,h.codename hyflname,y.codename ysxzname,j.codename jffsname,x.xm_id  from xm_sb x
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'hyfl')) h on h.codevalue = x.hyflbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'ysxz')) y on y.codevalue = x.ysxzbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'jffs')) j on j.codevalue = x.jffsbh
              where x.HHLXBH = 'DB' and x.id in
              (select distinct s.sbid from sgxt_rw_sb s left join sgxt_rwb r on s.sgxdrwid = r.id where s.sgxdrwid is null or r.shzt = 2)
             union all
              select x.id,x.hh,x.hm,x.dz,x.kj,x.mph,'yxd' type,h.codename hyflname,y.codename ysxzname,j.codename jffsname,x.xm_id from xm_sb x
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'hyfl')) h on h.codevalue = x.hyflbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'ysxz')) y on y.codevalue = x.ysxzbh
              left join (select * from xtgl_code where parentid = (select id from xtgl_code where type = 'jffs')) j on j.codevalue = x.jffsbh
              where x.HHLXBH = 'DB' and x.id in
              (select distinct s.sbid from sgxt_rw_sb s left join sgxt_rwb r on s.sgxdrwid = r.id where s.sgxdrwid is not null and r.shzt=1)
/

CREATE VIEW GET_WDRW_DBLB AS select t.taskid,t.rwblr, a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when nvl(t.check_time,sysdate)>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when sysdate>t.jssx then 1 else 0 end sfhuangd,
(select count(1) from XM_INSTANCE c where c.id=xm.id and c.id in (
        select d.contentvalue from wf_ru_inst_content d where LOWER (d.table_name) = 'xm_instance' and LOWER
        (d.contentname) = 'id' and d.proc_inst_id in (
        select e.proc_inst_id from wf_ru_inst e where e.pdef_id in ('30002','30003')))) iscontinue,
t.jssx_yl,case when sysdate>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.xmbh,xm.sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,zdjd.pdef_id zdjd,
t.refid,a.proc_inst_id,xm.lxr,f_get_activityname(zdjd.pdef_id) zdjd_str,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,xm.bmbm_qs,xm.xmfzr xmjl,
a.parammap rwbh from wf_task t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id
join wf_ru_inst_content b on t.proc_inst_id=b.proc_inst_id
join xm_instance xm on b.contentvalue=xm.id
join get_xmzdjd zdjd on zdjd.ID=xm.id
where a.procstatus=1 and upper(b.table_name)='XM_INSTANCE' and t.iscurrent>0 and xm.status=1

union all
select t.taskid,t.rwblr, a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when nvl(t.check_time,sysdate)>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when sysdate>t.jssx then 1 else 0 end sfhuangd,0 iscontinue,
t.jssx_yl,case when sysdate>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '1' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
t.refid,a.proc_inst_id,xm.lxr,'未立项' zdjd_str,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,'' bmbm_qs,xm.xmjl,
a.parammap rwbh from wf_task t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id
join wf_ru_inst_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_chgzsqb xm on b.contentvalue=xm.id
where a.procstatus=1 and upper(b.table_name)='YWSL_CHGZSQB' and t.iscurrent>0

union all
select t.taskid,t.rwblr,a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when nvl(t.check_time,sysdate)>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when sysdate>t.jssx then 1 else 0 end sfhuangd,0 iscontinue,
t.jssx_yl,case when sysdate>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '2' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
t.refid,a.proc_inst_id,xm.lxr,'未立项' zdjd_str,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,'' bmbm_qs,xm.xmjl,
a.parammap rwbh from wf_task t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id
join wf_ru_inst_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_gshbsqb xm on b.contentvalue=xm.id
where a.procstatus=1 and upper(b.table_name)='YWSL_GSHBSQB' and t.iscurrent>0

union all
select t.taskid,t.rwblr,a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when nvl(t.check_time,sysdate)>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when sysdate>t.jssx then 1 else 0 end sfhuangd,0 iscontinue,
t.jssx_yl,case when sysdate>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '3' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
t.refid,a.proc_inst_id,xm.lxr,'未立项' zdjd_str,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,'' bmbm_qs,xm.xmjl,
a.parammap rwbh from wf_task t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id
join wf_ru_inst_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_xjxqsqb xm on b.contentvalue=xm.id
where a.procstatus=1 and upper(b.table_name)='YWSL_XJXQSQB' and t.iscurrent>0
/

CREATE VIEW YS_YSJEZH AS select a.ID,a.YSRWZBID,b.MC,a.YSJE,a.BZ
from (YS_RWCB a inner join  XTGL_FYLX b  on a.YSFL = b.BH)
/

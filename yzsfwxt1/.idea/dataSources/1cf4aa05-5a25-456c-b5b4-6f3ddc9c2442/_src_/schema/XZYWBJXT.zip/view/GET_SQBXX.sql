CREATE VIEW GET_SQBXX AS select sflx,sqbh,'10' type,'居民科' sllx, a.id,a.lxr,a.lxrsjh,xmjl,f_get_username(xmjl) xmjl_str,f_get_mobilephone(xmjl) xmjl_sjh,xmmc,kfsmc dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_xjxqsqb a
where a.sflx = '0'
union all
select sflx,sqbh,'20' type,'工商科' sllx,b.id,b.lxr,b.lxrsjh,xmjl,f_get_username(xmjl) xmjl_str,f_get_mobilephone(xmjl) xmjl_sjh,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_gshbsqb b
where b.sflx = '0'
union all
select sflx,sqbh,'30' type,'户改科' sllx,c.id,c.lxr,c.lxrsjh,xmjl,f_get_username(xmjl) xmjl_str,f_get_mobilephone(xmjl) xmjl_sjh,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_chgzsqb c
where c.sflx = '0'
/

CREATE VIEW SGXD_HB AS select tymc,ldbs,ldbh,lfsx,zhs,type,xm_id from (
             select t.mc tymc,l.id ldbs,l.ldbh,s.xm_id,
             case when l.lfsx = 0 then '多层' when l.lfsx = 1 then '高层' else '' end lfsx,count(1) zhs,'wxd' type
              from xm_ld l
             left join xm_ty t on l.tyid = t.id and l.xmid = t.xmid
             left join xm_sb s on l.id = s.ldid and l.xmid = s.xm_id
             where  s.HHLXBH = 'HB'
              and l.id not in (select distinct ldid from sgxt_rw_sb where ldid is not null)
             group by l.ldbh,l.lfsx,t.mc,l.id,s.xm_id
             union all
            select t.mc tymc,l.id ldbs,l.ldbh,s.xm_id,
             case when l.lfsx = 0 then '多层' when l.lfsx = 1 then '高层' else '' end lfsx,count(1) zhs,'dxd' type
              from xm_ld l
             left join xm_ty t on l.tyid = t.id and l.xmid = t.xmid
             left join xm_sb s on l.id = s.ldid and l.xmid = s.xm_id
             where s.HHLXBH = 'HB'
              and l.id in (select distinct ldid from sgxt_rw_sb s left join sgxt_rwb r on s.sgxdrwid = r.id where s.sgxdrwid is null or r.shzt = 2)
             group by l.ldbh,l.lfsx,t.mc,l.id,s.xm_id
             union all
            select t.mc tymc,l.id ldbs,l.ldbh,s.xm_id,
             case when l.lfsx = 0 then '多层' when l.lfsx = 1 then '高层' else '' end lfsx,count(1) zhs,'yxd' type
              from xm_ld l
             left join xm_ty t on l.tyid = t.id and l.xmid = t.xmid
             left join xm_sb s on l.id = s.ldid and l.xmid = s.xm_id
             where s.HHLXBH = 'HB'
              and l.id in (select distinct ldid from sgxt_rw_sb s left join sgxt_rwb r on s.sgxdrwid = r.id where sgxdrwid is not null and r.shzt=1)
             group by l.ldbh,l.lfsx,t.mc,l.id,s.xm_id )
/

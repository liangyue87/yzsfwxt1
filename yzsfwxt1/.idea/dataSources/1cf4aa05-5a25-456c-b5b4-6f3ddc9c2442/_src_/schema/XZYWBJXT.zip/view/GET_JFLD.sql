CREATE VIEW GET_JFLD AS select m."TYMC",m."LDID",m."XMID",m."LDBH",m."LFSX",m."ZHS",nvl(n.yjsl,0) yjsl,(m.zhs-nvl(n.yjsl,0)) wyjsl,nvl(p.gxsl,0) gxsl from
(select y.mc tymc,l.id ldid,l.xmid,l.ldbh,case when l.lfsx = 0 then '多层' when l.lfsx = 1 then '高层' else '' end lfsx,count(1) zhs
 from xm_ld l left join xm_sb s on l.id = s.ldid and l.xmid = s.xm_id left join xm_ty y on l.tyid = y.id where s.hhlxbh = 'HB' group by y.mc,l.id,l.xmid,l.ldbh,l.lfsx) m
left join (select l.ldbh,count(1) yjsl from xm_ld l left join sfkp_sftzdcbsb y on l.id = y.ldid where y.SBLXBH = 'HB' and y.SFTZDCBID is not null and y.zzaz = 0 group by l.ldbh) n on m.ldbh = n.ldbh
left join (select l.ldbh,count(1) gxsl from xm_ld l left join sfkp_sftzdcbsb y on l.id = y.ldid where y.SBLXBH = 'HB' and y.SFTZDCBID is null and y.zzaz = 0 group by l.ldbh) p on m.ldbh = p.ldbh
/

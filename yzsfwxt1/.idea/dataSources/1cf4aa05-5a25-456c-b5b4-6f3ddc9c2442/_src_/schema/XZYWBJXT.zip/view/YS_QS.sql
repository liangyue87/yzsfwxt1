CREATE VIEW YS_QS AS select a.proc_inst_id procinstid,z.shyj,z.id zbid, z.sfsh, '0' yszt, a.startuser,a.startdt,a.pdef_id,t.czr,t.qssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when nvl(t.check_time,sysdate)>t.check_sx then '签收超时' else '签收未超时' end qssfcs，
t.check_time,t.jssx,case when sysdate>t.jssx then '黄灯' else '绿灯' end sfhuangd,
t.jssx_yl,case when sysdate>t.jssx_yl then '红灯' else '没红' end sfhongd,xm.id,xm.xmbh,xm.sqlx,xm.azlx,xm.sqbh,xm.xmmc,xm.xmdz,xm.lxr,xm.lxrsjh,xm.dwmc,to_char(xm.lxsj,'yyyy-mm-dd hh24:mi:ss')lxsj
from wf_task t
  join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id
  join wf_ru_inst_content b on t.proc_inst_id=b.proc_inst_id
  join xm_instance xm on b.contentvalue=xm.id
  join YS_RWZB z on xm.id=z.xmid
where a.procstatus=1 and upper(b.table_name)='XM_INSTANCE' and t.iscurrent=1 and xm.status=1 and t.C_ACTIVITYID = '40081' and z.sfsh='1'
/

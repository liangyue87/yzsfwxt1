CREATE VIEW ZHCX_ZHYSLB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.fqrq,t.yjyssj,t.sjyssj,t.rwclsj,CASE WHEN(t.fkjg=0) THEN '合格' WHEN (t.fkjg=1) THEN '不合格' END FKJG,t.ZT from zhys_rwzb t
join xm_instance a on t.xmid=a.id
/

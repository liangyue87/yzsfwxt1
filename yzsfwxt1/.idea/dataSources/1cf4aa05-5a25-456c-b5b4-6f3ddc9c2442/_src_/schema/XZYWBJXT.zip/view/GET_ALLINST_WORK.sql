CREATE VIEW GET_ALLINST_WORK AS select t.proc_inst_id,t.table_name,t.contentvalue,a.pdef_id,'yx' proc_status from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name) in ('XM_INSTANCE','YWSL_XJXQSQB','YWSL_GSHBSQB','YWSL_CHGZSQB')
union all
select t.proc_inst_id,t.table_name,t.contentvalue,a.pdef_id,'wc' proc_status from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name) in ('XM_INSTANCE','YWSL_XJXQSQB','YWSL_GSHBSQB','YWSL_CHGZSQB')
/

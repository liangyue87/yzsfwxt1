CREATE VIEW YS_VZP AS select b.XMBH,b.LXR,to_char(b.LXSJ,'yyyy-mm-dd hh24:mi:ss')LXSJ,b.LXRSJH,b.XMMC,b.DWMC,b.XMDZ,b.AZLX,a.YSZT,b.ID
from YS_RWZB a inner join  XM_INSTANCE b on a.XMID = b.ID and b.YSFZR is null
where a.yszt is not null
group by b.XMBH,b.LXR,LXSJ,b.LXRSJH,b.XMMC,b.DWMC,b.XMDZ,b.AZLX,a.YSZT,b.ID
/

CREATE VIEW V_HSJGLR AS with proc as (
select t.contentvalue,a.pdef_id,'yx' proc_status,t.proc_inst_id from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status,t.proc_inst_id from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=0 and upper(t.table_name)='XM_INSTANCE')

select '0' taskid,p.proc_inst_id,'' htyy,tt."ID",tt."PXMBH",tt."XMBH",tt."SQLX",tt."AZLX",tt."SLID",tt."SQBH",tt."XMLB",tt."XMTZF",tt."XMSWLXFL",tt."QBID",tt."STATUS",tt."SLRBH",to_char(tt.LXSJ,'yyyy-mm-dd hh24:mi:ss')lxsj,tt."XMFZR",tt."XMMC",tt."LXR",tt."LXRSJH",tt."XMDZ",tt."DWMC",tt."SLSJ",tt."ISZJ",tt."LXDH",tt."XZQYBH",tt."ZJZMJ",tt."SJFZR",tt."STFZR",tt."JLFZR",tt."ZJFZR",tt."YSFZR",tt."QSFZR",tt."SGFZR",tt."BZ",tt."BMBM_QS",tt."JHKSSJ",tt."JHJSSJ",tt."XMDZ_SHENG",tt."XMDZ_SHI",tt."XMDZ_XZQYBH",substr(p.pdef_id,0,1) FIRST,p.proc_status,p.pdef_id,'0' yszt
from xm_instance tt left join
(Select * from proc a where not exists(select 1 from proc where contentvalue=a.contentvalue and pdef_id>a.pdef_id)) p on tt.id=p.contentvalue
where  tt.pxmid is not null

union all

select y.taskid,p.proc_inst_id procinstid,y.htyy,tt."ID",tt."PXMBH",tt."XMBH",tt."SQLX",tt."AZLX",tt."SLID",tt."SQBH",tt."XMLB",tt."XMTZF",tt."XMSWLXFL",tt."QBID",tt."STATUS",tt."SLRBH",to_char(tt.LXSJ,'yyyy-mm-dd hh24:mi:ss')lxsj,tt."XMFZR",tt."XMMC",tt."LXR",tt."LXRSJH",tt."XMDZ",tt."DWMC",tt."SLSJ",tt."ISZJ",tt."LXDH",tt."XZQYBH",tt."ZJZMJ",tt."SJFZR",tt."STFZR",tt."JLFZR",tt."ZJFZR",tt."YSFZR",tt."QSFZR",tt."SGFZR",tt."BZ",tt."BMBM_QS",tt."JHKSSJ",tt."JHJSSJ",tt."XMDZ_SHENG",tt."XMDZ_SHI",tt."XMDZ_XZQYBH",substr(p.pdef_id,0,1) FIRST,p.proc_status,p.pdef_id,'1' yszt
from xm_instance tt
     left join (
select t.contentvalue,a.pdef_id,'yx' proc_status,t.proc_inst_id from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status,t.proc_inst_id from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=0 and upper(t.table_name)='XM_INSTANCE') p on tt.id=p.contentvalue
     left join WF_TASK y on p.proc_inst_id=y.proc_inst_id
where y.htyy is not null and y.iscurrent='1' and tt.status='1'
/

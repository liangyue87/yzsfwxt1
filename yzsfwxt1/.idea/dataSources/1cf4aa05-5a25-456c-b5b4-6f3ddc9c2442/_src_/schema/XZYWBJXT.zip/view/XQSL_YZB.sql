CREATE VIEW XQSL_YZB AS select x."ID",x."SQID",x."XMID",x."HH",x."HM",x."DZ",x."KJBH",x."YSXZBH",x."HYFLBH",x."KCHS",x."BZ",x."QSBH",k.mc kjmc,y.codename ysxz,h.codename hyfl from xm_yzb x left join xtgl_kj k on x.kjbh = k.bh
 left join (select c.* from xtgl_code c where c.parentid = (select id from xtgl_code where type = 'ysxz')) y on x.ysxzbh = y.codevalue
 left join (select c.* from xtgl_code c where c.parentid = (select id from xtgl_code where type = 'hyfl')) h on x.hyflbh = h.codevalue
/

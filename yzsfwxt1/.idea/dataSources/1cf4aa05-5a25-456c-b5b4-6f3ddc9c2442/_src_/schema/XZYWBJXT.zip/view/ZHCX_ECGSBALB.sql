CREATE VIEW ZHCX_ECGSBALB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.fqsj,t.fksj_sjy fksj_eg,t.czr_sjy czr_eg,f_get_sjhm(t.czr_sjy) lxfs,t.yj_sjy yj_eg,t.sbgys,t.sbgyslxr,t.sbgyslxdh  from xm_ecgsba t
join xm_instance a on t.xmid=a.id
/

CREATE VIEW BSLD_RWWCQKTJ AS select t.rwblr,count(case t.qssfcs when 1 then 1 else 0 end)+count(case t.sfhongd when 1 then 1 else 0 end) hongdbjsl,
count(case t.sfhuangd when 1 then 1 else 0 end) huangdbjsl,
count(case when t.qssfcs+t.sfhuangd+t.sfhongd=0 then 1 else 0 end) ldbjsl,count(t.taskid) bjzsl
 from get_wdrw_ybllb t
group by t.rwblr
/

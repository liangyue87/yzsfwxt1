CREATE VIEW XM_VFW AS with proc as (
      select  a.id,  a.xmid,  a.bh,  a.mc bfmc,  a.cjr, a.cjsj,  a.zt,'泵房'lb
      from XM_BF a
      union all
      select a.id,  a.xmid,  a.bh,  a.mc dxsmc,  a.cjr, a.cjsj,  a.zt,'地下室'lb
      from XM_DXS a
      union all
      select a.id,  a.xmid,  a.ldbh bh,  a.ldmc,  a.cjr, a.cjsj,  a.zt,'楼栋'lb
      from XM_LD a
      union all
      select a.id,  a.xmid,  a.bh,  a.mc tymc,  a.cjr, a.cjsj,  a.zt,'庭院'lb
      from XM_TY a
      union all
      select x.id,x.xmid,x.sxbh bh,x.sxmc,x.cjr,x.cjsj,x.zt,'水箱'lb
      from xm_sx x
)

 select p.lb,p.xmid,t.username cjr,max(to_char(cjsj,'yyyy-mm-dd hh24:mi:ss')) str_cjsj,count(p.lb) count
  from proc p
  left join xtgl_user t on p.cjr=t.userid
  group by p.lb,p.xmid,t.username
/

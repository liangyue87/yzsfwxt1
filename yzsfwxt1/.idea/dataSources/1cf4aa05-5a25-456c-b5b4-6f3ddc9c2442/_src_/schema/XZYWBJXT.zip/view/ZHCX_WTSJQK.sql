CREATE VIEW ZHCX_WTSJQK AS select "ZT","SJWCSJ","SJR","SJRSJH","ID","XMBH","XMMC","ZMJ","ZJMJ","HS","SJSTID","WTSJ","CONTENTVALUE" from
(select rw.sjstzt zt,rw.sjjssj sjwcsj,rw.username sjr, rw.mobilephone sjrsjh,n."ID",n."XMBH",n."XMMC",n."ZMJ",n."ZJMJ",n."HS",n."SJSTID"
 from
 (select * from sjst_rwb r left join xtgl_user b on  r.sjr=b.userId  )rw,
 (select t.*,s.sjstId from
 (select x.id,x.xmbh,x.xmmc,y.zjzmj zmj,y.zzjzmj zjmj,y.hs from XM_INSTANCE x left join ywsl_xjxqsqb y on x.qbid=y.sqbh and 1=1 ) t,
 xm_sjst_rela s  where  t.id=s.xmid ) n where  n.sjstid=rw.id)  r ,
(select w.jssj wtsj,h.contentvalue from WF_TASK_HISTORY w , WF_HI_INST_CONTENT h where w.proc_inst_id =h.proc_inst_id and w.C_ACTIVITYID = '30001') v where r.id=v.contentvalue
/

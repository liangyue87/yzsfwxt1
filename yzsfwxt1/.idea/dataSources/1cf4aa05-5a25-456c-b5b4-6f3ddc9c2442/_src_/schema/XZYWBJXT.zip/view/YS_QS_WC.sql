CREATE VIEW YS_QS_WC AS select t.contentid,t.proc_inst_id,t.table_name,t.contentremark,t.contentname,t.contenttype,t.contentvalue,s.pdef_id from
       wf_ru_inst_content t left join wf_ru_inst s on t.proc_inst_id=s.proc_inst_id
/

CREATE VIEW ZHCX_WTYSLB AS SELECT ins.id,ins.xmmc,ins.xmbh,z.yskssj,z.ysjssj,F_GET_SJHM(z.YSR) mobilephone,F_GET_USERNAME(z.YSR) username,sum(nvl(a.YSJE,0)) tygwysje,sum(nvl(b.YSJE,0)) shbfysje,sum(nvl(c.YSJE,0)) hbysje,
sum(nvl(d.YSJE,0)) dgysje,sum(nvl(f.YSJE,0)) sjysje,sum(nvl(g.YSJE,0)) jlysje,sum(nvl(h.YSJE,0)) ysze,z.YHQRSJ,z.YSZT  from YS_RWZB z
left join YS_RWCB a on a.YSRWZBID=z.id and a.YSFL='01'
left join YS_RWCB b on b.YSRWZBID=z.id and b.YSFL='02'
left join YS_RWCB c on c.YSRWZBID=z.id and c.YSFL='03'
left join YS_RWCB d on d.YSRWZBID=z.id AND d.YSFL='04' 
left join YS_RWCB e on e.YSRWZBID=z.id
left join YS_RWCB f on f.YSRWZBID=z.id AND f.YSFL='06' 
left join YS_RWCB g on g.YSRWZBID=z.id AND g.YSFL='07' 
left join YS_RWCB h on h.YSRWZBID=z.id
join XM_INSTANCE ins on z.xmid=ins.id
--where a.YSFL='01'  and c.YSFL='03' and d.YSFL='04' AND f.YSFL='06' AND g.YSFL='07'
GROUP BY ins.id,ins.xmmc,ins.xmbh,z.yskssj,z.ysjssj,F_GET_SJHM(z.YSR),F_GET_USERNAME(z.YSR),z.YHQRSJ,z.YSZT
/

CREATE VIEW GET_XMLB_SJST AS with proc as (select t.contentvalue,a.pdef_id,'yx' proc_status from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE')

select tt."ID",tt."PXMID",tt."XMBH",tt."SQLX",tt."AZLX",tt."SLID",tt."SQBH",tt."XMLB",tt."XMTZF",tt."XMSWLXFL",tt."QBID",tt."STATUS",tt."SLRBH",tt."LXSJ",tt."XMFZR",tt."XMMC",tt."LXR",tt."LXRSJH",tt."XMDZ",tt."DWMC",tt."SLSJ",tt."ISZJ",tt."LXDH",tt."XZQYBH",tt."ZJZMJ",tt."SJFZR",tt."STFZR",tt."JLFZR",tt."ZJFZR",tt."YSFZR",tt."QSFZR",tt."SGFZR",tt."BZ",tt."BMBM_QS",tt."JHKSSJ",tt."JHJSSJ",tt."XMDZ_SHENG",tt."XMDZ_SHI",tt."XMDZ_XZQYBH",tt."SLSJ_STR"/*,substr(p.pdef_id,0,1) FIRST,p.proc_status,p.pdef_id */
from xm_instance tt
--left join proc p on tt.id=p.contentvalue
where tt.pxmid is not null and not exists(select 1 from proc pr where tt.id=pr.contentvalue and substr(pr.pdef_id,0,1)='3')
/

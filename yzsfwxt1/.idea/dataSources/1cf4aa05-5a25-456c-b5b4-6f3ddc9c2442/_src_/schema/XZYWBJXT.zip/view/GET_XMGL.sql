CREATE VIEW GET_XMGL AS select t."ID",t."PXMID",t."XMBH",t."SQLX",t."AZLX",t."SLID",t."SQBH",t."XMLB",t."XMTZF",t."XMSWLXFL",t."QBID",t."STATUS",t."SLRBH",t."LXSJ",t."XMFZR",t."XMMC",t."LXR",t."LXRSJH",t."XMDZ",t."DWMC",t."SLSJ",t."ISZJ",t."LXDH",t."XZQYBH",t."ZJZMJ",t."SJFZR",t."STFZR",t."JLFZR",t."ZJFZR",t."YSFZR",t."QSFZR",t."SGFZR",t."BZ",t."BMBM_QS",t."JHKSSJ",t."JHJSSJ",t."XMDZ_SHENG",t."XMDZ_SHI",t."XMDZ_XZQYBH",t."USERID",t."PXMBH",t."SLSJ_STR",t."GSFS",sjst.SJR,ys.YSR,rela.sjstid,ys.id ysid from xm_instance t
left join xm_sjst_rela rela on t.id=rela.xmid
left join sjst_rwb sjst on rela.sjstid=sjst.id
left join ys_rwzb ys on t.id=ys.xmid
where t.pxmid is not null
/

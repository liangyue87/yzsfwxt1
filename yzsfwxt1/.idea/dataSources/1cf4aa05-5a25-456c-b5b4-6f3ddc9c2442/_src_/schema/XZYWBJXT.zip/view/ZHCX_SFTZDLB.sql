CREATE VIEW ZHCX_SFTZDLB AS select a.id,a.xmbh,a.xmmc,a.xmfzr,t.tzdbh,t.ysje,t.ssje,t.jfqrsj,t.pjh,t.kprq,t.tzdzt zt  from sfkp_sftzdzb t
join xm_instance a on t.xmid=a.id
/

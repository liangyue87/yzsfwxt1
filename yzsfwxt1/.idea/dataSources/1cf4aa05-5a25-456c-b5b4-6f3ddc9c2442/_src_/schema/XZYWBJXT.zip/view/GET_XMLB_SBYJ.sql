CREATE VIEW GET_XMLB_SBYJ AS with proc as (select t.contentvalue,a.pdef_id,'yx' proc_status from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where upper(t.table_name)='XM_INSTANCE')

select distinct tt."ID",tt."PXMID",tt."XMBH",tt."SQLX",tt."AZLX",tt."SLID",tt."SQBH",tt."XMLB",tt."XMTZF",tt."XMSWLXFL",tt."QBID",tt."STATUS",tt."SLRBH",tt."LXSJ",tt."XMFZR",tt."XMMC",tt."LXR",tt."LXRSJH",tt."XMDZ",tt."DWMC",tt."SLSJ",tt."ISZJ",tt."LXDH",tt."XZQYBH",tt."ZJZMJ",tt."SJFZR",tt."STFZR",tt."JLFZR",tt."ZJFZR",tt."YSFZR",tt."QSFZR",tt."SGFZR",tt."BZ",tt."BMBM_QS",tt."JHKSSJ",tt."JHJSSJ",tt."XMDZ_SHENG",tt."XMDZ_SHI",tt."XMDZ_XZQYBH",tt."SLSJ_STR",tt."SJYSSJ",
substr(p.pdef_id,0,1) FIRST,p.proc_status from (select x.*,z.sjyssj from xm_instance x left join zhys_rwzb z on x.id = z.xmid) tt left join
proc p on tt.id=p.contentvalue
where substr(p.pdef_id,0,1)='7'  and tt.pxmid is not null
/

CREATE VIEW GET_WDRW_YBLLB AS select t.taskid,t.rwblr, a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.jssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when t.check_time>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when t.jssj>t.jssx then 1 else 0 end sfhuangd,
t.jssx_yl,case when t.jssj>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.xmbh,xm.sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,zdjd.pdef_id zdjd,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,
a.parammap rwbh from wf_task_history t
join get_all_inst a on t.proc_inst_id=a.proc_inst_id
join get_all_content b on t.proc_inst_id=b.proc_inst_id
join xm_instance xm on b.contentvalue=xm.id
join get_xmzdjd zdjd on zdjd.ID=xm.id
where upper(b.table_name)='XM_INSTANCE' and xm.status=1--and t.iscurrent=0

union all
select t.taskid,t.rwblr, a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.jssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when t.check_time>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when t.jssj>t.jssx then 1 else 0 end sfhuangd,
t.jssx_yl,case when t.jssj>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '1' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,
a.parammap rwbh from wf_task_history t
join get_all_inst a on t.proc_inst_id=a.proc_inst_id
join get_all_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_chgzsqb xm on b.contentvalue=xm.id
where upper(b.table_name)='YWSL_CHGZSQB' --and t.iscurrent=0

union all
select t.taskid,t.rwblr,a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.jssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when t.check_time>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when t.jssj>t.jssx then 1 else 0 end sfhuangd,
t.jssx_yl,case when t.jssj>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '2' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,
a.parammap rwbh from wf_task_history t
join get_all_inst a on t.proc_inst_id=a.proc_inst_id
join get_all_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_gshbsqb xm on b.contentvalue=xm.id
where upper(b.table_name)='YWSL_GSHBSQB' --and t.iscurrent=0

union all
select t.taskid,t.rwblr,a.startuser,a.startdt,a.pdef_id,t.c_activityid,t.iscurrent,t.htyy,t.czr,t.qssj,t.jssj,t.ischeck,t.check_sx,decode(t.ischeck,1,'已签收','未签收') qszt,
case when t.check_time>t.check_sx then 1 else 0 end qssfcs,
t.check_time,t.jssx,case when t.jssj>t.jssx then 1 else 0 end sfhuangd,
t.jssx_yl,case when t.jssj>t.jssx_yl then 1 else 0 end sfhongd,xm.id,xm.sqbh xmbh, '3' sqlx,f_get_azlx_str(xm.azlx) azlx,xm.sqbh,xm.xmmc,xm.xmdz,'' zdjd,
f_get_activityname(t.c_activityid) activityname,f_get_username(t.czr) fsr,to_char(t.qssj,'yyyy-mm-dd hh24:mi:ss') fssj,
to_char(t.jssx,'yyyy-mm-dd hh24:mi:ss') y_str,to_char(t.jssx_yl,'yyyy-mm-dd hh24:mi:ss') r_str,
a.parammap rwbh from wf_task_history t
join get_all_inst a on t.proc_inst_id=a.proc_inst_id
join get_all_content b on t.proc_inst_id=b.proc_inst_id
join ywsl_xjxqsqb xm on b.contentvalue=xm.id
where upper(b.table_name)='YWSL_XJXQSQB' --and t.iscurrent=0
/

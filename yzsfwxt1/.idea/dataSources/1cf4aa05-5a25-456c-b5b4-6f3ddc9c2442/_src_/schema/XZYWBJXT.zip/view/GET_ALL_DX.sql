CREATE VIEW GET_ALL_DX AS select dxmbid, taskid from dx_dfs
union all
select dxmbid, taskid from dx_fsjl t
/

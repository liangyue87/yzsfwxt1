CREATE VIEW GET_XCKCXX AS select '0' lxzt,sqbh xmbh,sqbh,'10' type, a.id,a.lxr,a.lxrsjh,xmjl,xmmc,kfsmc dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd hh24:mi:ss')slrq,xzqybh from ywsl_xjxqsqb a
where a.id  in (select sqid from xckc_rwzb where sqlb = '10')
union all
select '0' lxzt,sqbh xmbh,sqbh,'20' type,b.id,b.lxr,b.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd hh24:mi:ss')slrq,xzqybh from ywsl_gshbsqb b
where b.id in (select sqid from xckc_rwzb where sqlb = '20')
union all
select '0' lxzt,sqbh xmbh,sqbh,'30' type,c.id,c.lxr,c.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd hh24:mi:ss')slrq,xzqybh from ywsl_chgzsqb c
where c.id  in (select sqid from xckc_rwzb where sqlb = '30')
union all
select '1' lxzt,d.xmbh,sqbh, f_get_name(d.azlx) type,d.id,d.lxr,d.lxrsjh,xmfzr,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz,slrbh slr,to_char(slsj,'yyyy-mm-dd hh24:mi:ss') slrq,xzqybh from xm_instance d
where d.id  in (select xmid from xm_xckc_rela)
/

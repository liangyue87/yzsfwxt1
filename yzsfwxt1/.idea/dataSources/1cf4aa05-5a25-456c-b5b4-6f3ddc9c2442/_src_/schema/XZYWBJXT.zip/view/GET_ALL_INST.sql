CREATE VIEW GET_ALL_INST AS select proc_inst_id, pdef_id, parammap, startdt, startuser, null endtime, procstatus, stopuser, stopdt from wf_ru_inst
union all
select proc_inst_id, pdef_id, parammap, startdt, startuser, endtime, procstatus, stopuser, stopdt from wf_hi_inst
/

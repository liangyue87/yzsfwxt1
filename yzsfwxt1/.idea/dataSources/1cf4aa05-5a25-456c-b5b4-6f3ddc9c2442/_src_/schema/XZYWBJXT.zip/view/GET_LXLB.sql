CREATE VIEW GET_LXLB AS select sqbh,'10' type,'居民科' sllx, a.id,a.lxr,a.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_xjxqsqb a
where sflx='0' and fpzt in ('1','2')
union all
select sqbh,'20' type,'工商科' sllx,b.id,b.lxr,b.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_gshbsqb b
where sflx='0' and fpzt in ('1','2')
union all
select sqbh,'30' type,'户改科' sllx,c.id,c.lxr,c.lxrsjh,xmjl,xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xzqybh,xmdz, slr,to_char(slrq,'yyyy-mm-dd')slrq from ywsl_chgzsqb c
where sflx='0' and fpzt in ('1','2')
/

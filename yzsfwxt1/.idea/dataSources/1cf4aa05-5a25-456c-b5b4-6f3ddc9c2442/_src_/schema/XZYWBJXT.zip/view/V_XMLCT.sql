CREATE VIEW V_XMLCT AS select '0' type,id ,xmbh xmbh,xmmc,lxr,lxrsjh,azlx,to_char(slsj,'yyyy-mm-dd')slsj_str  from XM_INSTANCE v where 1=1 and v.pxmid is not null
   union all
  select '1' type,id,sqbh xmbh,xmmc,lxr,lxrsjh,azlx,to_char(slrq,'yyyy-mm-dd')slsj_str  from YWSL_XJXQSQB a where a.sflx='0'
   union all
  select '2' type,id,sqbh xmbh,xmmc,lxr,lxrsjh,azlx,to_char(slrq,'yyyy-mm-dd')slsj_str  from YWSL_GSHBSQB b where b.sflx='0'
    union all
  select '3' type,id,sqbh xmbh,xmmc,lxr,lxrsjh,azlx,to_char(slrq,'yyyy-mm-dd')slsj_str  from YWSL_CHGZSQB c where c.sflx='0'
/

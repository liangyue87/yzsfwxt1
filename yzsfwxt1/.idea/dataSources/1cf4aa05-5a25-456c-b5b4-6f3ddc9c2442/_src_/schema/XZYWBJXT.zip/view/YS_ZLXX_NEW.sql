CREATE VIEW YS_ZLXX_NEW AS select B.XMID, a.ID FJID,b.ID YSZBID,c.USERID,a.FJMC,a.FJHZ,to_char(a.SCSJ,'yyyy-mm-dd hh24:mi:ss') SCSJ, c.USERNAME,a.FJLJ
from ys_rwzb b
     left join ys_rwfj a on b.id=a.ysrwid
     left join XTGL_USER c  on c.USERID in a.SCR
/

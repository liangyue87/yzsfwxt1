CREATE VIEW GET_XQSL AS select a.jhkgsj,a.zjlxdh,a."LXZT",a."SQBH",a."FWXZ",a."TYPEID",a."AZLX",a."ID",a."LXR",a."FPZT",a."LXRSJH",a."XMMC",a."DWMC",a."XMDZ_SHENG",a."XMDZ_SHI",a."XMDZ_XZQYBH",a."XMDZ",a."SLR",a."SLRQ",a."XZQYBH",a."BZ",a."XMJL",a."YHXZ",a."ZJZMJ",a."ZZJZMJ",a."YXAZSL",a."JSYT",a."YHH",a."YBKJ",a."DKJC",a."HS",a."SJFW",a."DYLH",a."GHBFS",a."JFSJ",a."FQQK",a."XYSFS",a."XYSZK",a."XHXZK",a."LFHS",a."PFHS",a."LFDS",a."ZGCS",a."CKYSS",a."CPYSS",a."MMYSS",a."GCYSS",a."WYYSS",a."QTYS",a."NBXF",a."XQMC",x.codename
type from (select to_char(a.jhkgsj,'yyyy-mm-dd') jhkgsj,a.zjlxdh,'0' lxzt,a.sqbh,'10' typeid, a.azlx,a.FWXZ,a.id,a.lxr,a.FPZT,a.lxrsjh,a.XMMC,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,slrq,xzqybh,a.bz,a.xmjl,a.yhxz,a.zjzmj,a.zzjzmj,0 yxazsl,
'' jsyt,'' yhh,''ybkj, a.dkjc ,a.hs ,a.sjfw ,a.dylh ,a.ghbfs ,a.jfsj,a.fqqk,'' xysfs,'' xyszk,'' xhxzk ,0 lfhs,0 pfhs,0 lfds,0 zgcs,0 ckyss,0 cpyss,0 mmyss,0 gcyss,0 wyyss,'' qtys,0 nbxf,'' xqmc
from ywsl_xjxqsqb a
where a.id not in (select sqid from xckc_rwzb where sqlb = '1' and sqid is not null)) a
 left join (select * from xtgl_code where parentid in (select id from xtgl_code where type = 'sqlx')) x on a.typeid = x.codevalue
union all
select b.jhkgsj,b.zjlxdh,b."LXZT",b."SQBH",b."FWXZ",b."TYPEID",b."AZLX",b."ID",b."LXR",b."FPZT",b."LXRSJH",b."XMMC",b."DWMC",b."XMDZ_SHENG",b."XMDZ_SHI",b."XMDZ_XZQYBH",b."XMDZ",b."SLR",b."SLRQ",b."XZQYBH",b."BZ",b."XMJL",b."YHXZ",b."ZJZMJ",b."ZZJZMJ",b."YXAZSL",b."JSYT",b."YHH",b."YBKJ",b."DKJC",b."HS",b."SJFW",b."DYLH",b."GHBFS",b."JFSJ",b."FQQK",b."XYSFS",b."XYSZK",b."XHXZK",b."LFHS",b."PFHS",b."LFDS",b."ZGCS",b."CKYSS",b."CPYSS",b."MMYSS",b."GCYSS",b."WYYSS",b."QTYS",b."NBXF",b."XQMC",x.codename
from (select to_char(b.jhkgsj,'yyyy-mm-dd') jhkgsj,b.zjlxdh,'0' lxzt,b.sqbh,'20' typeid,''FWXZ, b.AZLX,b.id,b.lxr,b.FPZT,b.lxrsjh,b.xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,slrq,xzqybh, b.bz,b.xmjl,b.yhxz, 0 zjzmj, 0 zzjzmj,b.yxazsl,b.jsyt,b.yhh,b.ybkj,
 ''dkjc,0 hs,''sjfw,''dylh,0 ghbfs,sysdate jfsj,''fqqk,'' xysfs,'' xyszk,'' xhxzk ,0 lfhs,0 pfhs,0 lfds,0 zgcs,0 ckyss,0 cpyss,0 mmyss,0 gcyss,0 wyyss,'' qtys,0 nbxf,'' xqmc
 from ywsl_gshbsqb b
  where b.id not in (select sqid from xckc_rwzb where sqlb = '2' and sqid is not null)) b
  left join (select * from xtgl_code where parentid in (select id from xtgl_code where type = 'sqlx')) x on b.typeid = x.codevalue
union all
select c.jhkgsj,c.zjlxdh,c."LXZT",c."SQBH",c."FWXZ",c."TYPEID",c."AZLX",c."ID",c."LXR",c."FPZT",c."LXRSJH",c."XMMC",c."DWMC",c."XMDZ_SHENG",c."XMDZ_SHI",c."XMDZ_XZQYBH",c."XMDZ",c."SLR",c."SLRQ",c."XZQYBH",c."BZ",c."XMJL",c."YHXZ",c."ZJZMJ",c."ZZJZMJ",c."YXAZSL",c."JSYT",c."YHH",c."YBKJ",c."DKJC",c."HS",c."SJFW",c."DYLH",c."GHBFS",c."JFSJ",c."FQQK",c."XYSFS",c."XYSZK",c."XHXZK",c."LFHS",c."PFHS",c."LFDS",c."ZGCS",c."CKYSS",c."CPYSS",c."MMYSS",c."GCYSS",c."WYYSS",c."QTYS",c."NBXF",c."XQMC",x.codename
from (select to_char(c.jhkgsj,'yyyy-mm-dd') jhkgsj,c.zjlxdh,'0' lxzt,c.sqbh,'30' typeid,''FWXZ,c.AZLX,c.id,c.lxr,c.FPZT,c.lxrsjh,c.xmmc,dwmc,xmdz_sheng,xmdz_shi,xmdz_xzqybh,xmdz, slr,slrq,xzqybh, c.bz,c.xmjl,''yhxz,0 zjzmj, 0 zzjzmj,0 yxazsl,'' jsyt,'' yhh,''ybkj,
''dkjc,0 hs,''sjfw,''dylh,0 ghbfs,sysdate jfsj,''fqqk,c.xysfs,c.xyszk,c.xhxzk,c.lfhs,c.pfhs,c.lfds,c.zgcs,c.ckyss,c.cpyss,c.mmyss,c.gcyss,c.wyyss,c.qtys,c.nbxf,c.xqmc
from ywsl_chgzsqb c
 where c.id not in (select sqid from xckc_rwzb where sqlb = '3' and sqid is not null)) c
 left join (select * from xtgl_code where parentid in (select id from xtgl_code where type = 'sqlx')) x on c.typeid = x.codevalue
/

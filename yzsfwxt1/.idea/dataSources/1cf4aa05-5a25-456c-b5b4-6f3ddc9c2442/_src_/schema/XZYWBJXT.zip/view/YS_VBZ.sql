CREATE VIEW YS_VBZ AS select  b.XMBH,b.LXR,to_char(b.LXSJ,'yyyy-mm-dd hh24:mi:ss')LXSJ,b.DWMC,b.AZLX,b.XMDZ,a.YSZT,A.YSR,b.LXRSJH,b.XMMC,a.XMID,a.ID
from YS_RWZB a  inner join XM_INSTANCE b on a.XMID = b.ID and  a.YSR  is  not null
/

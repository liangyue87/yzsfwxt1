CREATE VIEW GET_XMLB_JF AS with proc as (select t.contentvalue,a.pdef_id,'yx' proc_status from wf_ru_inst_content t
join wf_ru_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE'
union all
select t.contentvalue,a.pdef_id,'wc' proc_status from wf_hi_inst_content t
join wf_hi_inst a on t.proc_inst_id=a.proc_inst_id where a.procstatus=1 and upper(t.table_name)='XM_INSTANCE')

select tt."ID",tt."PXMID",tt."XMBH",tt."SQLX",tt."AZLX",tt."SLID",tt."SQBH",tt."XMLB",tt."XMTZF",tt."XMSWLXFL",tt."QBID",tt."STATUS",tt."SLRBH",tt."LXSJ",tt."XMFZR",tt."XMMC",tt."LXR",tt."LXRSJH",tt."XMDZ",tt."DWMC",tt."SLSJ",tt."ISZJ",tt."LXDH",tt."XZQYBH",tt."ZJZMJ",tt."SJFZR",tt."STFZR",tt."JLFZR",tt."ZJFZR",tt."YSFZR",tt."QSFZR",tt."SGFZR",tt."BZ",tt."BMBM_QS",tt."JHKSSJ",tt."JHJSSJ",tt."XMDZ_SHENG",tt."XMDZ_SHI",tt."XMDZ_XZQYBH",tt."SLSJ_STR",
 tt."USERNAME",tt."VAZLX" from
 (select x.*,u.username,c.codename vazlx from xm_instance x left join xtgl_user u on x.lxr = u.userid
  left join (select * from xtgl_code c where c.parentid in (select id from xtgl_code where parentid in (select id from xtgl_code where type = 'azlx'))) c on c.codevalue = x.azlx) tt
where tt.pxmid is not null and not exists(select 1 from proc pr where tt.id=pr.contentvalue and substr(pr.pdef_id,0,1)='6')  and tt.pxmid is not null
/

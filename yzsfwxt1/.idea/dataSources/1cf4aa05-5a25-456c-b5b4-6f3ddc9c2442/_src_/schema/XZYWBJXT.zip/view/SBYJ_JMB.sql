CREATE VIEW SBYJ_JMB AS select m.ldid,m."LDMC",m."XM_ID",m."ZHS",nvl(n.yjsl,0) yjsl,(m.zhs-nvl(n.yjsl,0)) wyjsl from
  (select l.id ldid,l.ldmc,s.xm_id，count(1) zhs from xm_ld l left join xm_sb s on l.id = s.ldid left join sgxt_rw_sb a on s.id = a.sbid and s.hhlxbh = a.type left join sgxt_rwb w
    on a.sgxdrwid = w.id and s.xm_id = w.xmid where s.hhlxbh = 'HB' group by l.ldmc,s.xm_id,l.id) m
  left join (select l.ldmc,count(1) yjsl from xm_ld l left join yj_sbyjcb y on l.id = y.ldid where y.hhlxbh = 'HB' group by l.ldmc) n on m.ldmc = n.ldmc
/

CREATE VIEW SBYJSH_GSB AS select s.id,s.xm_id,s.hh,s.yyzx_hh,s.hm,s.dz yhdz,s.azwz zbdz,to_char(s.sgsj,'yyyy-MM-dd') azrq,to_char(s.tssj,'yyyy-MM-dd') tsrq,to_char(s.yyzx_xcyjrq,'yyyy-MM-dd') xcyjrq,s.ds xzds,s.ybds chjbds,
         s.bsm,case when s.dxfw = 'Y' then '有' else '无' end dxfw,case when s.zsljf = 0 then '否' else '是' end dsljf,s.bch,s.gps,s.yyzx_yyzxry yyzxry,s.sgry,to_char(s.sgryqzsj,'yyyy-MM-dd') sgryqzsj,
         s.yhqr,to_char(s.yhqrqzsj,'yyyy-MM-dd') yhqrqzsj,u.username LXR,s.lxdh,s.bz,
         c.codename jffs,s.ysxzbh,d.codename ysxz,s.hyflbh,h.codename hyfl,e.mc bzkj,f.mc zbkj,sbcj.mc sbcj,g.codename sblx,s.pqbh,p.mc pq from yj_sbyjcb c left join yj_sbyjzb z on c.sbyjzbid = z.id
             left join xm_sb s on c.sbid = s.id and c.hhlxbh = s.hhlxbh
             left join (select * from xtgl_code c where c.parentid = (select id from xtgl_code where type = 'jffs')) c on s.jffsbh = c.codevalue
             left join (select * from xtgl_code d where d.parentid = (select id from xtgl_code where type = 'ysxz')) d on s.ysxzbh = d.id
             left join (select * from xtgl_code d where d.parentid in (select d.id from xtgl_code d where d.parentid = (select id from xtgl_code where type = 'ysxz'))) h on s.hyflbh = h.codevalue
             left join xtgl_kj e on s.kjbh = e.bh
             left join xtgl_kj f on s.sgdw_sbkj = f.bh
             left join xtgl_sbcj sbcj on s.sbcjbh = sbcj.bh
             left join xtgl_pq p on p.bh = s.pqbh
             left join xtgl_user u on u.userid = s.LXR
             left join (select * from xtgl_code g where g.parentid = (select id from xtgl_code where type = 'sblx')) g on s.SBLXBH = g.codevalue
         where s.hhlxbh = 'DB'
/
